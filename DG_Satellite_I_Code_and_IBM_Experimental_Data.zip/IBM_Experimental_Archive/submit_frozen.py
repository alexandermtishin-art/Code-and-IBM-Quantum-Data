#!/usr/bin/env python3
"""
Submit EXACTLY the already frozen backend-specific QASM set.

Security:
  - API key must be in IBM_QUANTUM_API_KEY
  - do NOT paste the key into this file or chat

Usage example:
  python submit_frozen.py \
    --freeze-dir DG_IBM_backend_freeze/ibm_kingston \
    --backend ibm_kingston

This script:
  1) verifies the existing NATIVE_SHA256_MANIFEST.txt
  2) loads the existing frozen QASM files
  3) checks circuit count
  4) submits exactly those circuits with fixed shots=1536
  5) writes SUBMISSION.json with job id and manifest hash

It does NOT regenerate or transpile the circuits.
"""

import os, sys, json, argparse, hashlib, time
from pathlib import Path

try:
    from qiskit import qasm3
    from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2
except Exception as e:
    raise SystemExit(
        "Missing packages. Install with:\n"
        "  python -m pip install -U qiskit qiskit-ibm-runtime\n\n"
        f"Import error: {e}"
    )

SHOTS = 1536
EXPECTED_CIRCUITS = 116

def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def service_from_env():
    token = os.environ.get("IBM_QUANTUM_API_KEY")
    if not token:
        raise SystemExit("IBM_QUANTUM_API_KEY is not set.")
    instance = os.environ.get("IBM_QUANTUM_INSTANCE") or None
    kwargs = dict(channel="ibm_quantum_platform", token=token)
    if instance:
        kwargs["instance"] = instance
    return QiskitRuntimeService(**kwargs)

def verify_manifest(freeze_dir):
    manifest = freeze_dir / "NATIVE_SHA256_MANIFEST.txt"
    if not manifest.exists():
        raise SystemExit(f"Missing manifest: {manifest}")

    text = manifest.read_text(encoding="utf-8").splitlines()
    qasm_entries = []
    for line in text:
        line = line.strip()
        if not line or line.startswith("DG IBM") or line.startswith("{"):
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            continue
        expected, rel = parts
        p = freeze_dir / rel
        if not p.exists():
            raise SystemExit(f"Manifest file missing: {p}")
        actual = sha256_file(p)
        if actual != expected:
            raise SystemExit(
                f"HASH MISMATCH for {rel}\nexpected {expected}\nactual   {actual}"
            )
        if rel.startswith("qasm/") and rel.endswith(".qasm"):
            qasm_entries.append((rel, p))
    qasm_entries.sort()
    return manifest, qasm_entries

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--freeze-dir", required=True)
    ap.add_argument("--backend", required=True)
    args = ap.parse_args()

    freeze_dir = Path(args.freeze_dir)
    manifest, entries = verify_manifest(freeze_dir)

    if len(entries) != EXPECTED_CIRCUITS:
        raise SystemExit(
            f"Expected {EXPECTED_CIRCUITS} frozen QASM files, found {len(entries)}"
        )

    print("Manifest verified.")
    print("Manifest SHA256:", sha256_file(manifest))
    print("Frozen circuits:", len(entries))

    circuits = []
    for rel, p in entries:
        qc = qasm3.load(p)
        circuits.append(qc)

    service = service_from_env()
    backend = service.backend(args.backend)

    sampler = SamplerV2(mode=backend)
    job = sampler.run(circuits, shots=SHOTS)

    info = {
        "backend": args.backend,
        "job_id": job.job_id(),
        "submitted_unix_time": time.time(),
        "shots_per_circuit": SHOTS,
        "n_circuits": len(circuits),
        "manifest_sha256": sha256_file(manifest),
        "freeze_dir": str(freeze_dir),
    }
    out = freeze_dir / "SUBMISSION.json"
    out.write_text(json.dumps(info, indent=2), encoding="utf-8")

    print("\nSUBMITTED EXACTLY FROZEN CIRCUITS")
    print(json.dumps(info, indent=2))
    print("\nDo not modify the frozen files now.")

if __name__ == "__main__":
    main()

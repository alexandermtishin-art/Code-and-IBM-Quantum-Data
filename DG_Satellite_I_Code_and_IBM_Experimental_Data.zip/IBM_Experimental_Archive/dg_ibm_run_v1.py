#!/usr/bin/env python3
"""
DG IBM Channel-Tick experiment runner v1
Frozen runner for the preregistered A/B/C experiment.

SECURITY:
  Put your IBM Quantum API key in the environment variable IBM_QUANTUM_API_KEY.
  Do NOT paste the key into this file or into chat.

Examples:
  # 1) list accessible hardware
  python dg_ibm_run_v1.py --list

  # 2) instantiate and freeze backend-specific circuits, but DO NOT submit
  python dg_ibm_run_v1.py --backend ibm_<name> --freeze-only

  # 3) after checking the printed manifest, submit exactly the frozen circuits
  python dg_ibm_run_v1.py --backend ibm_<name> --submit

Optional:
  export IBM_QUANTUM_INSTANCE="<CRN-or-service-name>"
"""

import os, sys, json, math, argparse, hashlib, time
from pathlib import Path

try:
    from qiskit import QuantumCircuit, transpile, qasm3
    from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2
except Exception as e:
    raise SystemExit(
        "Missing packages. Install with:\n"
        "  python -m pip install -U qiskit qiskit-ibm-runtime\n\n"
        f"Import error: {e}"
    )

# -------- frozen constants --------
VERSION = "DG_IBM_RUNNER_v1_2026-09-21"
THETA_STEP = 0.10
DET_DTHETA = 0.30
N_POINTS = 12
SHOTS = 1536
SLOW_DELAY_SX_MULT = 4
BASES = ("X", "Y", "Z")
FAMILIES = ("A_GEODESIC_FAST", "B_GEODESIC_SLOW", "C_DETOUR")
PRIMARY_D_STAR = 0.15
SENSITIVITY_D_STAR = (0.10, 0.15, 0.20, 0.25)

def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()

def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def service_from_env():
    token = os.environ.get("IBM_QUANTUM_API_KEY")
    if not token:
        raise SystemExit(
            "IBM_QUANTUM_API_KEY is not set.\n"
            "Set it in your shell; do not paste the key into this script."
        )
    instance = os.environ.get("IBM_QUANTUM_INSTANCE") or None
    kwargs = dict(channel="ibm_quantum_platform", token=token)
    if instance:
        kwargs["instance"] = instance
    return QiskitRuntimeService(**kwargs)

def rx_native(qc, q, theta):
    # Exact up to a global phase:
    # Rx(theta) ~ Rz(pi/2) SX Rz(theta+pi) SX Rz(pi/2)
    qc.rz(math.pi / 2, q)
    qc.sx(q)
    qc.rz(theta + math.pi, q)
    qc.sx(q)
    qc.rz(math.pi / 2, q)

def h_native(qc, q):
    qc.rz(math.pi / 2, q)
    qc.sx(q)
    qc.rz(math.pi / 2, q)

def add_basis_rotation(qc, q, basis):
    if basis == "Z":
        return
    if basis == "X":
        h_native(qc, q)
        return
    if basis == "Y":
        qc.rz(-math.pi / 2, q)
        h_native(qc, q)
        return
    raise ValueError(basis)

def read_prop(props, q, name, default=float("inf")):
    try:
        val = props.qubit_property(q, name)[0]
        return float(val)
    except Exception:
        return default

def sx_error(backend, q):
    try:
        err = backend.target["sx"][(q,)].error
        return float(err) if err is not None else float("inf")
    except Exception:
        return float("inf")

def sx_duration(backend, q):
    try:
        d = backend.target["sx"][(q,)].duration
        if d is None:
            raise ValueError
        return float(d)
    except Exception:
        raise RuntimeError(f"SX duration unavailable for physical qubit {q}")

def select_qubit(backend):
    props = backend.properties()
    cand = []
    for q in range(backend.num_qubits):
        ro = read_prop(props, q, "readout_error")
        se = sx_error(backend, q)
        if math.isfinite(ro) and math.isfinite(se):
            cand.append((ro + se, q, ro, se))
    if not cand:
        raise RuntimeError("No eligible qubit with both readout_error and sx_error.")
    cand.sort(key=lambda x: (x[0], x[1]))
    return cand[0]  # score, q, ro, se

def build_logical(family, j, basis, delay_seconds):
    qc = QuantumCircuit(1, 1, name=f"{family}_j{j:02d}_{basis}")
    q = 0

    if family == "C_DETOUR":
        rx_native(qc, q, +DET_DTHETA)
        qc.barrier(q)
        rx_native(qc, q, -DET_DTHETA)
        qc.barrier(q)

    for _ in range(j):
        rx_native(qc, q, THETA_STEP)
        if family == "B_GEODESIC_SLOW":
            qc.delay(delay_seconds, q, unit="s")

    add_basis_rotation(qc, q, basis)
    qc.measure(q, 0)
    return qc

def ref_zero(k):
    qc = QuantumCircuit(1, 1, name=f"REF_ZERO_{k}")
    qc.measure(0, 0)
    return qc

def ref_one(k):
    qc = QuantumCircuit(1, 1, name=f"REF_ONE_{k}")
    qc.sx(0)
    qc.sx(0)
    qc.measure(0, 0)
    return qc

def list_backends(service):
    rows = []
    for b in service.backends(simulator=False, operational=True):
        try:
            status = b.status()
            pending = getattr(status, "pending_jobs", None)
            op = getattr(status, "operational", None)
        except Exception:
            pending, op = None, None
        rows.append((b.name, b.num_qubits, pending, op))
    rows.sort(key=lambda x: (10**9 if x[2] is None else x[2], x[0]))
    print("backend\tqubits\tpending_jobs\toperational")
    for r in rows:
        print("\t".join(map(str, r)))

def instantiate(service, backend_name, outdir):
    backend = service.backend(backend_name)
    score, q, ro, se = select_qubit(backend)
    sxd = sx_duration(backend, q)
    delay_s = SLOW_DELAY_SX_MULT * sxd

    outdir.mkdir(parents=True, exist_ok=True)
    qasm_dir = outdir / "qasm"
    qasm_dir.mkdir(exist_ok=True)

    circuits = []
    inventory = []

    for fam in FAMILIES:
        for j in range(N_POINTS):
            for basis in BASES:
                logical = build_logical(fam, j, basis, delay_s)
                isa = transpile(
                    logical,
                    backend=backend,
                    initial_layout=[q],
                    optimization_level=0,
                    scheduling_method="alap",
                )
                circuits.append(isa)
                inventory.append({
                    "index": len(circuits)-1,
                    "name": isa.name,
                    "family": fam,
                    "point_index": j,
                    "basis": basis,
                })

    for k in range(4):
        isa = transpile(ref_zero(k), backend=backend, initial_layout=[q],
                        optimization_level=0, scheduling_method="alap")
        circuits.append(isa)
        inventory.append({"index": len(circuits)-1, "name": isa.name,
                          "family":"REFERENCE_ZERO", "point_index":-1, "basis":"Z"})

    for k in range(4):
        isa = transpile(ref_one(k), backend=backend, initial_layout=[q],
                        optimization_level=0, scheduling_method="alap")
        circuits.append(isa)
        inventory.append({"index": len(circuits)-1, "name": isa.name,
                          "family":"REFERENCE_ONE", "point_index":-1, "basis":"Z"})

    meta = {
        "runner_version": VERSION,
        "backend": backend_name,
        "physical_qubit": q,
        "qubit_selection_score": score,
        "readout_error": ro,
        "sx_error": se,
        "sx_duration_s": sxd,
        "B_delay_after_each_increment_s": delay_s,
        "theta_step_rad": THETA_STEP,
        "detour_dtheta_rad": DET_DTHETA,
        "n_points": N_POINTS,
        "shots_per_circuit": SHOTS,
        "n_circuits": len(circuits),
        "total_shots": len(circuits) * SHOTS,
        "primary_D_star": PRIMARY_D_STAR,
        "sensitivity_D_star": SENSITIVITY_D_STAR,
        "optimization_level": 0,
        "scheduling_method": "alap",
    }
    (outdir / "instantiation_metadata.json").write_text(
        json.dumps(meta, indent=2), encoding="utf-8")
    (outdir / "inventory.json").write_text(
        json.dumps(inventory, indent=2), encoding="utf-8")

    # Freeze exact QASM before submission
    for i, qc in enumerate(circuits):
        p = qasm_dir / f"{i:03d}_{qc.name}.qasm"
        p.write_text(qasm3.dumps(qc), encoding="utf-8")

    lines = [
        "DG IBM BACKEND-SPECIFIC NATIVE FREEZE — SHA256\n",
        json.dumps(meta, sort_keys=True) + "\n\n"
    ]
    for p in sorted(qasm_dir.glob("*.qasm")):
        lines.append(f"{sha256_file(p)}  qasm/{p.name}\n")
    for p in (outdir/"instantiation_metadata.json", outdir/"inventory.json"):
        lines.append(f"{sha256_file(p)}  {p.name}\n")
    manifest = outdir / "NATIVE_SHA256_MANIFEST.txt"
    manifest.write_text("".join(lines), encoding="utf-8")

    return backend, circuits, meta, manifest

def submit_job(backend, circuits, outdir):
    # IBM docs: SamplerV2(mode=<backend>).run(pubs, shots=...)
    sampler = SamplerV2(mode=backend)
    job = sampler.run(circuits, shots=SHOTS)

    job_info = {
        "job_id": job.job_id(),
        "submitted_unix_time": time.time(),
        "shots_per_circuit": SHOTS,
        "n_circuits": len(circuits),
    }
    (outdir / "SUBMISSION.json").write_text(
        json.dumps(job_info, indent=2), encoding="utf-8")
    print("\nSUBMITTED")
    print(json.dumps(job_info, indent=2))
    print("\nDo not change the frozen circuits or analysis plan now.")
    return job

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true",
                    help="List accessible operational non-simulator backends.")
    ap.add_argument("--backend", help="Exact IBM backend name.")
    ap.add_argument("--freeze-only", action="store_true",
                    help="Instantiate + hash circuits, but do not submit.")
    ap.add_argument("--submit", action="store_true",
                    help="Submit the exactly instantiated circuits.")
    ap.add_argument("--out", default="DG_IBM_backend_freeze",
                    help="Output directory for backend-specific freeze.")
    args = ap.parse_args()

    service = service_from_env()

    if args.list:
        list_backends(service)
        return

    if not args.backend:
        raise SystemExit("Specify --backend NAME, or use --list first.")

    if args.freeze_only and args.submit:
        raise SystemExit("Choose either --freeze-only or --submit, not both.")
    if not args.freeze_only and not args.submit:
        raise SystemExit("Choose --freeze-only first; later rerun with --submit.")

    outdir = Path(args.out) / args.backend
    backend, circuits, meta, manifest = instantiate(
        service, args.backend, outdir)

    print("\nBACKEND-SPECIFIC FREEZE CREATED")
    print(json.dumps(meta, indent=2))
    print("Manifest:", manifest)
    print("Manifest SHA256:", sha256_file(manifest))

    if args.freeze_only:
        print("\nNo QPU job was submitted.")
        print("Archive this directory/manifest before submission.")
        return

    # IMPORTANT: --submit regenerates deterministically from current calibration.
    # For strict confirmatory use, run --freeze-only and --submit back-to-back
    # without calibration refresh or code changes, or preserve the same snapshot.
    submit_job(backend, circuits, outdir)

if __name__ == "__main__":
    main()

DG Satellite I: preservation-first edition based on user-supplied 17-page MAIN (2026-11-01).
MAIN retains every original paragraph and table in order; new sections 6.10–6.12 are inserted before §7.
Supplement retains all S1–S20 and adds S21–S25. No new universal DG theorem is claimed.
Separate DG mathematical-object research remains a distinct research branch; additions here are scoped safeguards.
Archive legacy original is stored without modification; current Supplement and this README override nothing.

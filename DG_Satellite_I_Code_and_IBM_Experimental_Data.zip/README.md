# DG Satellite I public research code and experiment summaries

**Main manuscript and Supplement are distributed separately, NOT included in this archive.**

This release preserves existing public scripts and research notes and adds explicitly labelled derived IBM summaries. The derived CSVs are not original raw IBM job output. See `experiment/PROVENANCE_AND_LIMITS.md`. Other scripts and historical notes remain under their legacy paths for traceability.

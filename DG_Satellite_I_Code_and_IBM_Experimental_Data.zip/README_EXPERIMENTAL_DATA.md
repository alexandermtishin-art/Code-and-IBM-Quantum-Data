# DG Satellite I — Code and IBM Experimental Data

This archive combines earlier DG Satellite I code, notes and manuscript-reported aggregates with the separately supplied IBM quantum-computing experiment archive.

## Experimental sources
IBM_Experimental_Archive/ contains the original user-supplied CSV data, job metadata, Jupyter notebooks, source scripts and nested frozen-run packages, including JSON count files and QASM circuits. Nested ZIPs preserve protocol provenance. The parent archive was provided on 2026-11-02.

## Scope limitation
The uploaded experiment archive includes wide and multi-backend DG data and tests 3–8, but it does not contain a verified original shot-count source file for the specific August 2026 IBM qubit-141 Linear job d9vavtl0vrcc73bp0ueg. The manuscript's qubit-141 figures remain manuscript-reported until that job's primary records are located. Do not conflate different experimental campaigns.

## Security
The source archive contained an IBM Quantum API token in notebook source. This public edition replaces that token with a placeholder and excludes a document containing an API key. Do not publish the unredacted source ZIP. The original key should be revoked if active.

## Reproducibility
The files retain experimental CSVs and code, with nested job-level count JSON, QASM, and processing scripts where supplied. Availability of files does not guarantee every reported result is independently reproducible without IBM hardware settings or execution calibration snapshots.

## Manuscripts
MAIN and SUPPLEMENT are distributed separately and not packaged here.

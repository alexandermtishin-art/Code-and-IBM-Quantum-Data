import numpy as np, json
I=np.eye(2,dtype=complex); X=np.array([[0,1],[1,0]],complex); Z=np.diag([1,-1]).astype(complex)
H=(X+Z)/np.sqrt(2); e0=np.array([1,0],complex)
rows=[]
for phi in [0,np.pi/3,np.pi/2,np.pi,3*np.pi/2,2*np.pi]:
    rz=np.diag([np.exp(-1j*phi/2),np.exp(1j*phi/2)])
    psi=rz@H@e0
    after=H@psi
    pz=float(abs(psi[0])**2)
    px=float(abs(after[0])**2)
    rows.append({'phi_over_pi':round(phi/np.pi,6),'z_readout_0':round(pz,10),'ramsey_x_readout_0':round(px,10),'cos2_prediction':round(float(np.cos(phi/2)**2),10)})
assert all(abs(r['z_readout_0']-.5)<1e-9 for r in rows)
assert all(abs(r['ramsey_x_readout_0']-r['cos2_prediction'])<1e-9 for r in rows)
# Finite operational records indistinguishable under Z but distinguished under X-context
print(json.dumps(rows,indent=2))
with open('/mnt/data/DG_Satellite_SingleQubit_Phase_Oracle.json','w') as f:json.dump({'source':'standard Hilbert qubit independent oracle, NOT DG derivation or IBM measurement','rows':rows},f,indent=2)

"""Exhaustive Boolean (no probabilities) Hardy-support extension test."""
from itertools import product
supports = {(0,0): {(0,0),(0,1),(1,0),(1,1)},
            (0,1): {(0,0),(0,1),(1,1)},
            (1,0): {(0,0),(1,0),(1,1)},
            (1,1): {(0,0),(0,1),(1,0)}}
assignments=[]
for a0,a1,b0,b1 in product((0,1),repeat=4):
    vals={(0,0):(a0,b0),(0,1):(a0,b1),(1,0):(a1,b0),(1,1):(a1,b1)}
    if all(vals[ctx] in supports[ctx] for ctx in supports):
        assignments.append((a0,a1,b0,b1))
print('global assignments:',assignments)
for ctx in supports:
    print('context',ctx,'support',sorted(supports[ctx]),'extendable',sorted({(x[ctx[0]],x[2+ctx[1]]) for x in assignments}))
assert (1,1) in supports[(0,0)]
assert not any(a0 == 1 and b0 == 1 for a0,a1,b0,b1 in assignments)
assert all({a for a,b in supports[(x,y)]} == {0,1} and {b for a,b in supports[(x,y)]} == {0,1} for x,y in supports)
print('PASS: possible (1,1|00) is not extendable to any local global assignment.')

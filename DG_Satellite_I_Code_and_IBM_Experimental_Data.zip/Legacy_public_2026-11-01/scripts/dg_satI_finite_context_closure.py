"""Finite deterministic operational context closure; no quantum or probabilistic axioms."""
from collections import defaultdict

def refine(states, alphabet, outputs, transitions):
    def partition(sig):
        labels={}; result={}
        for state in states:
            key=sig[state]
            if key not in labels: labels[key]=len(labels)
            result[state]=labels[key]
        return result
    p=partition(outputs)
    stages=[p]
    while True:
        signatures={s:(outputs[s],tuple(p[transitions[(s,a)]] for a in alphabet)) for s in states}
        q=partition(signatures)
        if all((p[x]==p[y])==(q[x]==q[y]) for x in states for y in states):break
        stages.append(q);p=q
    return stages

if __name__=='__main__':
    states=tuple(range(4)); alphabet=('a',)
    # 0 and 1 indistinguishable at terminal readout; continuation makes them distinguishable.
    output={0:0,1:0,2:1,3:0}
    trans={(0,'a'):2,(1,'a'):3,(2,'a'):2,(3,'a'):3}
    stages=refine(states,alphabet,output,trans)
    print('number_of_states=',len(states))
    for depth,p in enumerate(stages):print('max_context_length=',depth,'partition=',p)
    assert stages[0][0]==stages[0][1] and stages[1][0]!=stages[1][1]
    assert len(stages)-1 <=len(states)-1

import numpy as np,csv
from pathlib import Path
P=Path('/mnt/data')
r=np.array([0.,0.,1.]); axes={'X':np.array([1.,0.,0.]),'Y':np.array([0.,1.,0.])}
contexts={'Z':np.array([[0.,0.,1.]]),'XZ':np.array([[1.,0.,0.],[0.,0.,1.]]),'XYZ':np.eye(3),'XY':np.array([[1.,0.,0.],[0.,1.,0.]])}
rows=[]
for name,M in contexts.items():
    B=np.column_stack([np.cross(a,r) for a in axes.values()])
    J=.5*M@B
    rank=np.linalg.matrix_rank(J,tol=1e-12)
    rows.append(dict(contexts=name,control_directions=2,rank=rank,unobservable_directions=2-rank,Jacobian=np.array2string(J,precision=2)))
with (P/'DG_direction_observability_qubit_table.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print(rows)

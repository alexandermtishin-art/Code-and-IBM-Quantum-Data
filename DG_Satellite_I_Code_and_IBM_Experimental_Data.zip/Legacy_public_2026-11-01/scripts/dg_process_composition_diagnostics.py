import pandas as pd
from pathlib import Path
p=Path(__file__).parent
x=pd.read_csv(p/'DG_IBM_AB_by_k_2026-10-26.csv')
f=x[x.archive=='finescan'].set_index('k')
rec=[]
for k in (5,7):
 for seq in ('A','B'):
  v=float(f.loc[k,'mean_'+seq]); baseline=(float(f.loc[k-1,'mean_'+seq])+float(f.loc[k+1,'mean_'+seq]))/2
  rec.append({'k':k,'seq':seq,'observed':v,'neighbor_even_interpolation':baseline,'excess':v-baseline})
out=pd.DataFrame(rec)
out.to_csv(p/'DG_IBM_finescan_odd_even_excess.csv',index=False)
print(out.to_string(index=False))
print('Mean excess by seq:',out.groupby('seq').excess.mean().to_dict())

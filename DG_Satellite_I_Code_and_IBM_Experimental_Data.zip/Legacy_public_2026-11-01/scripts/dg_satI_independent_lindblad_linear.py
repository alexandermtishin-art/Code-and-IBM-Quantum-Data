import numpy as np, json,csv
from scipy.linalg import expm
from pathlib import Path
root=Path('/mnt/data')
T1=368.9e-6; T2=226.7e-6; tau=32e-9
G1=1/T1; Gphi=1/T2-1/(2*T1)
X=np.array([[0,1],[1,0]],complex); Y=np.array([[0,-1j],[1j,0]],complex); Z=np.diag([1.,-1.]); sm=np.array([[0,1],[0,0]],complex); I=np.eye(2,dtype=complex)
# vec column-major; Liouvillian for Hamiltonian, lowering and pure dephasing
H=np.pi/(4*tau)*X # U_sx = exp(-i*pi*X/4) up to phase
L=-1j*(np.kron(I,H)-np.kron(H.T,I))
def dissipator(c):
 C=c.conj().T@c
 return np.kron(c.conj(),c)-.5*(np.kron(I,C)+np.kron(C.T,I))
L+=G1*dissipator(sm)+Gphi/2*dissipator(Z)
E=expm(L*tau)

def run(seq,k):
 r=np.array([[1,0],[0,0]],complex).reshape(4,order='F')
 for _ in range(k):
  for phi in seq:
   ang=np.deg2rad(phi)
   V=np.diag([np.exp(1j*ang/2),np.exp(-1j*ang/2)]) # rz(-phi)
   r=(V@r.reshape((2,2),order='F')@V.conj().T).reshape(4,order='F')
   r=E@r
   V=V.conj().T # rz(+phi)
   r=(V@r.reshape((2,2),order='F')@V.conj().T).reshape(4,order='F')
 rho=r.reshape((2,2),order='F');return float(rho[1,1].real),float(np.trace(rho).real)
rows=[];d=json.load(open(root/'linear_result(1).json'))['rows']
for k in (20,60):
 for name,ph in [('A',[270,0,0,270]),('B',[180,0,0,0])]:
  v,trace=run(ph,k)
  obs=sum(row['counts']['1'] for row in d if row['k']==k and row['seq']==name)/120000
  m=.002+.996*v
  rows.append({'k':k,'history':name,'pulse_count':4*k,'sx_time_us':4*k*tau*1e6,'model_pre_readout':v,'model_with_symmetric_ro_0p002':m,'observed_error':obs,'obs_minus_model':obs-m,'trace':trace})
with open(root/'DG_SatI_independent_Lindblad_linear.csv','w',newline='') as f:
 w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)
print('gamma1',G1,'gammaphi',Gphi,'Tphi_us',1/Gphi*1e6)
for r in rows:print(r)

import itertools,json
bits=(0,1)
settings=list(itertools.product(bits,repeat=2))
full={f'{x}{y}':[(a,b) for a,b in itertools.product(bits,repeat=2)] for x,y in settings}
forbidden={'01':(1,0),'10':(0,1),'11':(1,1)}
hardy={k:[v for v in vals if v!=forbidden.get(k)] for k,vals in full.items()}
assignments=list(itertools.product(bits,repeat=4)) # a0 a1 b0 b1

def compatible(support,ass):
 a0,a1,b0,b1=ass;a=(a0,a1);b=(b0,b1)
 return all((a[x],b[y]) in support[f'{x}{y}'] for x,y in settings)

def covers_hardy(ass):
 return ass[0]==1 and ass[2]==1

summary={}
for name,support in [('classical_full',full),('hardy',hardy)]:
 permitted=[a for a in assignments if compatible(support,a)]
 summary[name]={'compatible_assignments':len(permitted),'cover_hardy_event':sum(map(covers_hardy,permitted)), 'locally_possible':{f'{x}{y}':{'Alice':sorted(set(a for a,b in support[f'{x}{y}'])),'Bob':sorted(set(b for a,b in support[f'{x}{y}']))} for x,y in settings}}
for key in forbidden:
 relaxed={k:list(v) for k,v in hardy.items()}
 relaxed[key].append(forbidden[key])
 witnesses=[a for a in assignments if compatible(relaxed,a) and covers_hardy(a)]
 summary['remove_'+key+'_zero']={'witnesses':witnesses}
assert summary['hardy']['compatible_assignments']==5
assert summary['hardy']['cover_hardy_event']==0
assert summary['classical_full']['cover_hardy_event']>0
assert all(summary['remove_'+k+'_zero']['witnesses'] for k in forbidden)
with open('/mnt/data/DG_Quantum_Logical_Boundary_Verification.json','w') as f:json.dump(summary,f,indent=2,ensure_ascii=False)
print(json.dumps(summary,indent=2))

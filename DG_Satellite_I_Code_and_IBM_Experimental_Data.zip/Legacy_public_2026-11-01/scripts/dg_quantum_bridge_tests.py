import numpy as np, csv, json
from scipy.integrate import simpson
from scipy.optimize import minimize_scalar
alpha=.310
omega=2*np.pi*alpha

def signal(T,tau,grid=25001):
 t=np.linspace(0,T,grid)
 f=np.ones_like(t)
 l=t<tau; r=t>T-tau
 f[l]=.5*(1-np.cos(np.pi*t[l]/tau))
 f[r]=.5*(1-np.cos(np.pi*(T-t[r])/tau))
 return t,f/(T-tau) # fixed pulse area

def response(T,tau,weight='uniform'):
 t,f=signal(T,tau)
 if weight=='uniform': w=np.ones_like(t)
 elif weight=='ramp': w=np.exp(1j*0.11*t)
 elif weight=='quadratic': w=1+0.7*f/np.max(f)
 return simpson(f*w*np.exp(1j*omega*t),x=t)

rows=[]
for T in (50.,60.,80.,100.):
 for n in (1,2,3):
  tau=(n+.5)/alpha
  if 2*tau>=T: continue
  A0=response(T,tau,'uniform'); A1=response(T,tau,'ramp'); A2=response(T,tau,'quadratic')
  # baseline deterministic readout constructed solely from area of pulse, not transition model
  t,f=signal(T,tau)
  area=simpson(f,x=t)
  rows.append(dict(T_ns=T,n=n,tau_ns=tau,uniform_F_abs=abs(A0),ramp_weight_F_abs=abs(A1),quadratic_weight_F_abs=abs(A2),area_only_response=area))
assert len(rows)==12
assert max(x['uniform_F_abs'] for x in rows)<1e-9
assert max(abs(x['area_only_response']-1) for x in rows)<1e-10
# operational models: measured event stream alone does not specify which response map is correct
with open('/mnt/data/DG_Quantum_Bridge_Countermodels.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with open('/mnt/data/DG_Quantum_Bridge_Countermodels.json','w') as f:
 json.dump({'interpretation':'Same prescribed pulse controls, different permitted response functionals. No claims about actual IBM leakage or predicting Duffing dynamics.','cases':rows,'max_uniform_residual':max(x['uniform_F_abs'] for x in rows),'min_ramp_nonzero':min(x['ramp_weight_F_abs'] for x in rows)},f,indent=2)
print('cases',len(rows),'max uniform',max(x['uniform_F_abs'] for x in rows),'min ramp',min(x['ramp_weight_F_abs'] for x in rows),'min quadratic',min(x['quadratic_weight_F_abs'] for x in rows))

from math import isclose
s=(0.,1.,0.); t=(0.,-1.,0.)
def Rz90(v): return (-v[1],v[0],v[2])
def D(u,v): return sum((a-b)**2 for a,b in zip(u,v))
def q(v): return v[0]
assert q(s)==q(t)==0
assert D(Rz90(s),Rz90(t))==D(s,t)==4
assert abs(q(Rz90(s))-q(Rz90(t)))/2==1
assert abs(q(s)-q(t))/2==0
print('PASS: identical initial Q, D preserved, output separation 1 after rotation; identity separation 0.')

import json, numpy as np, csv, collections
from pathlib import Path
root=Path('/mnt/data')
rows=json.loads((root/'finescan_result(1).json').read_text())['rows']
agg=collections.defaultdict(list)
for r in rows: agg[(r['seq'],int(r['k']))].append(float(r['err']))
series={s:np.array([np.mean(agg[s,k]) for k in range(4,9)]) for s in 'AB'}
series['B_minus_A']=series['B']-series['A']
out=[]
for name, vals in series.items():
 H=np.array([[vals[i+j] for j in range(3)] for i in range(3)])
 sv=np.linalg.svd(H,compute_uv=False)
 out.append({'series':name,'k_values':'4,5,6,7,8','means':';'.join(f'{v:.9f}' for v in vals),'hankel_det_3x3':f'{np.linalg.det(H):.12g}', 'sv1':f'{sv[0]:.12g}','sv2':f'{sv[1]:.12g}','sv3':f'{sv[2]:.12g}','n_reps_each':10})
with (root/'DG_SatI_Hankel_Descriptive_Novelty_Gate_2026-10-27.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=out[0].keys());w.writeheader();w.writerows(out)
for o in out:print(o)

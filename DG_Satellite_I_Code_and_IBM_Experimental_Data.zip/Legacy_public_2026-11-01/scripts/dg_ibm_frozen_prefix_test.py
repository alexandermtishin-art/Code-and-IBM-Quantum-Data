"""Frozen-prefix descriptive tests. No DG dynamics inferred. Run: python dg_ibm_frozen_prefix_test.py"""
from pathlib import Path
import pandas as pd
import numpy as np
ROOT=Path(__file__).parent
D=pd.read_csv(ROOT/'DG_IBM_AB_by_k_2026-10-26.csv')
settings=[('evenscan',[2,4,6,8],[10,12]),('finescan',[4,5,6],[7,8])]
rows=[]
for archive,train,test in settings:
    sub=D[D.archive==archive].set_index('k')
    for outcome in ['mean_A','mean_B','mean_delta']:
        xs=np.asarray(train,dtype=float); ys=sub.loc[train,outcome].to_numpy()
        slope,intercept=np.polyfit(xs,ys,1)
        for k in test:
            observed=float(sub.loc[k,outcome]); forecast=float(slope*k+intercept)
            rows.append(dict(archive=archive,observable=outcome,train_k=','.join(map(str,train)),test_k=k,
                    slope_per_repetition=float(slope),intercept=float(intercept),forecast=forecast,
                    observed=observed,residual=observed-forecast,absolute_error=abs(observed-forecast),
                    zero_baseline_absolute_error=abs(observed),last_seen_baseline_absolute_error=abs(observed-ys[-1])))
O=pd.DataFrame(rows)
O.to_csv(ROOT/'DG_IBM_AB_frozen_prefix_predictions_2026-10-26.csv',index=False)
for (archive,outcome), group in O.groupby(['archive','observable'],sort=False):
    print(archive,outcome,'MAE(linear)',round(group.absolute_error.mean(),9),'MAE(last)',round(group.last_seen_baseline_absolute_error.mean(),9))
print('Saved',len(O),'rows')

import numpy as np, json
from pathlib import Path
from math import pi
out=[]
def test(name, ok, detail):
    out.append({'id':name,'pass':bool(ok),'detail':detail})
    if not ok: raise AssertionError(name+': '+detail)
I=np.eye(2,dtype=complex); X=np.array([[0,1],[1,0]],complex);Z=np.diag([1,-1]).astype(complex)
H=np.array([[1,1],[1,-1]],complex)/np.sqrt(2)
e0=np.array([1,0],complex)
# Two distinct rays give identical Z counts / readout law.
plus=H@e0; minus=Z@plus
fz=lambda a: np.array([abs(a[0])**2,abs(a[1])**2])
test('Q11-Z-only-incompleteness', np.allclose(fz(plus),fz(minus)) and abs(np.vdot(plus,minus))<1e-12, 'orthogonal |+>,|-> yield the same Z-readout distribution (1/2,1/2)')
# A second measurement resolves the ambiguity
fx=lambda a: fz(H@a)
test('Q12-complementary-readout',np.allclose(fx(plus),[1,0]) and np.allclose(fx(minus),[0,1]),'X-readout discriminates same pair perfectly')
# Phase family with Z readout constant, X varying
phis=np.linspace(0,2*pi,101)
family=np.array([(e0+np.exp(1j*p)*np.array([0,1]))/np.sqrt(2) for p in phis])
test('Q13-phase-invisible-Z', np.max(np.abs(np.array([fz(a)[0] for a in family])-0.5))<1e-12,'101 relative phases have identical Z populations')
test('Q14-phase-visible-X', abs(fx(family[0])[0]-1)<1e-12 and abs(fx(family[50])[0])<1e-12,'X readout responds to relative phase (after calibrated H)')
# Monotonic transforms preserve state distinction, but can alter distances; d and d' bounded angular metric using chordal and FS.
theta=np.linspace(0,pi,71)
rays=np.array([np.cos(t/2)*e0+np.sin(t/2)*np.array([0,1]) for t in theta]);
dfs=lambda a,b: np.arccos(np.clip(abs(np.vdot(a,b)),0,1)); dch=lambda a,b: np.sqrt(max(0,2-2*abs(np.vdot(a,b))))
a,b,c=rays[0],rays[13],rays[54]
test('Q15-nonunique-metric', dfs(a,c)>0 and dch(a,c)>0 and abs(dfs(a,c)/dfs(a,b)-dch(a,c)/dch(a,b))>1e-3, 'Fubini-Study angular and projective chordal metrics induce same equality yet unequal ratios')
# Triangle check for projective chord metric on 71-point ray set
D=np.array([[dch(v,w) for w in rays] for v in rays]);
test('Q16-chord-metric-valid', np.max(D[:,:,None]-D[:,None,:]-D[None,:,:])<1e-8, 'projective chordal distance obeys triangle inequality on 71 rays')
# distinct channel dynamics with identical single endpoint readout on a limited probe, fix Z prep Z measurement; rotations about Z leave |0> data invariant
rz=lambda t: np.diag([np.exp(-0.5j*t),np.exp(0.5j*t)])
test('Q17-dynamics-underdetermined',all(np.allclose(fz(rz(t)@e0),[1,0]) for t in np.linspace(-8,8,101)) and not np.allclose(rz(0.4),rz(1.1)), '101 different Z rotations are unobservable in |0> input/Z output protocol')
# Identical unparameterized control orbit with different calibrated speed; at t1 fixed distinguishable
u=lambda t: np.cos(t/2)*I-1j*np.sin(t/2)*X
rates=[0.7,1.4]
end=[fz(u(v*0.8)@e0)[1] for v in rates]
test('Q18-control-rate-not-fixed', abs(end[0]-end[1])>0.05,'same one-parameter X rotation orbit, different rate yields different readout at calibrated t=0.8')
# Finite exact bitstring supports arbitrary Bernoulli p interior; underdetermination of parameter logically
record=np.array([0,1,1,0,0,1,0,0,1,0]); prob=lambda p: np.prod(np.where(record==1,p,1-p))
test('Q19-finite-string-probability',prob(.25)>0 and prob(.65)>0 and .25!=.65, 'same ten-event record has positive likelihood under both p=0.25 and p=0.65')
# Endpoint identity standard, not new test: param sweep
test('Q20-endpoint-identity', all(abs(fz(u(t)@e0)[1]-np.sin(t/2)**2)<1e-12 for t in np.linspace(-8,8,501)), '501 points verify standard qubit Born/FS endpoint identity; simulation only')
# Qualitative models: functions compatible with same binary distinction and control action can carry different frequencies (not derived)
test('Q21-operational-probability-freedom', all(0<p<1 and 0<q<1 for p,q in [(0.25,0.65),(0.4,0.8)]), 'two nonzero-full-support statistical models preserve possible outcome labels, disagree numerically')
# For source-free phase label, pure-ray 1-param same Z record but distinct state; express actual trace orthogonality
test('Q22-distinguishability-context', abs(np.vdot(plus,minus))<1e-12 and np.allclose(fz(plus),fz(minus)), 'distinguishability depends on allowed contexts, not intrinsic labels alone')
Path('/mnt/data/DG_Quantum_Satellite_Test_Results.json').write_text(json.dumps({'scope':'synthetic analytic countermodels; no IBM raw data','tests':out,'passed':sum(x['pass'] for x in out)},indent=2,ensure_ascii=False))
print('PASS',len(out),'of',len(out))

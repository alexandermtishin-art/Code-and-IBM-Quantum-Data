import csv,json,glob,statistics
from pathlib import Path
root=Path('/mnt/data')
cal=json.load(open(glob.glob(str(root/'readout_calib_result*'))[0]))
p01,p10=cal['p01'],cal['p10']; q=1-p01-p10
out=[]
for archive in ('evenscan','finescan','linear'):
 d=json.load(open(glob.glob(str(root/f'{archive}_result*'))[0]))
 rows=d['rows'];groups={}
 for r in rows:
  k=int(r['k']); seq=r['seq'];rep=r.get('rep',r.get('block'))
  err=float(r.get('err',r.get('p_err',0)))
  # Correction assumes same confusion matrix at experiment and error refers to wrong ideal target bit.
  wrong_target_bit = 1 if k%2==0 else 0
  floor = p01 if wrong_target_bit==1 else p10
  corrected=(err-floor)/q
  groups.setdefault((k,rep),{})[seq]=(err,corrected)
 for (k,rep),ab in sorted(groups.items()):
  if set(ab)=={'A','B'}:
   a,b=ab['A'],ab['B']
   out.append(dict(archive=archive,k=k,rep=rep,err_A=a[0],err_B=b[0],delta_raw=b[0]-a[0],corrected_A=a[1],corrected_B=b[1],delta_corrected=b[1]-a[1],target=int(k%2),readout_floor=(p01 if k%2==0 else p10)))
with open(root/'DG_IBM_readout_sensitivity_pairs_2026-10-27.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
print('calibration',cal['job_id'],'p01',p01,'p10',p10,'scale',q)
for arc in ('evenscan','finescan','linear'):
 z=[v for v in out if v['archive']==arc]
 print(arc,len(z),'raw_delta',statistics.mean(v['delta_raw'] for v in z),'corrected',statistics.mean(v['delta_corrected'] for v in z),'negative_corrected_A',sum(v['corrected_A']<0 for v in z),'negative_B',sum(v['corrected_B']<0 for v in z))
 print('odd',[(k,round(statistics.mean(v['err_A'] for v in z if v['k']==k),6)) for k in sorted(set(v['k'] for v in z))])

"""Reproduce descriptive matched A/B summaries from original IBM JSON files."""
import json
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).parent
for filename in ('evenscan_result(2).json','finescan_result(1).json','linear_result(1).json'):
    doc=json.loads((ROOT/filename).read_text())
    pairs=defaultdict(dict)
    for r in doc['rows']:
        key=(r.get('q',doc.get('qubit',141)), r['k'],r.get('rep',r.get('block',0)))
        pairs[key][r['seq']]=r.get('err',r.get('p_err'))
    matched=[(key, val['B']-val['A']) for key,val in pairs.items() if 'A' in val and 'B' in val]
    print(filename,'pairs',len(matched),'mean_B_minus_A',sum(v for _,v in matched)/len(matched),'B_gt_A',sum(v>0 for _,v in matched),'B_lt_A',sum(v<0 for _,v in matched))
    for k in sorted(set(key[1] for key,_ in matched)):
        x=[v for key,v in matched if key[1]==k]
        print('  k',k,'n',len(x),'mean',sum(x)/len(x))

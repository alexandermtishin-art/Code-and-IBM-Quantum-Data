import json
from pathlib import Path
import numpy as np
import pandas as pd
p=Path(__file__).parent
f=json.loads((p/'finescan_result(1).json').read_text())
df=pd.DataFrame(f['rows']); means=df.groupby(['k','seq'])['err'].mean().unstack()
ro=json.loads((p/'readout_calib_result(2).json').read_text())
rows=[]
for seq in ['A','B']:
    y=means[seq].to_numpy(); k=means.index.to_numpy(); X=np.column_stack([np.ones(len(k)),k,k%2])
    b=np.linalg.lstsq(X,y,rcond=None)[0]
    resid=y-X@b
    rows.append({'sequence':seq,'intercept':b[0],'slope_per_k':b[1],'odd_offset':b[2],'residual_rms_for_5_means':float(np.sqrt(np.mean(resid**2))),'readout_p01_separate_run':ro['p01'],'readout_p10_separate_run':ro['p10']})
out=pd.DataFrame(rows);out.to_csv(p/'DG_SatI_parity_readout_coefficients.csv',index=False)
print(means.to_string());print(out.to_string(index=False));print('readout asymmetry',ro['p10']-ro['p01'])

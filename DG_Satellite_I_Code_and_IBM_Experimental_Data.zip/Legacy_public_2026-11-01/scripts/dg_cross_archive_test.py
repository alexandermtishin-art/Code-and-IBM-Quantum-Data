import json,glob,csv,collections,numpy as np
from pathlib import Path
out=Path('/mnt/data')
results={}
for name in ('evenscan','finescan','linear'):
 d=json.load(open(glob.glob(str(out/(name+'_result*json')))[0])); rows=d['rows']; groups=collections.defaultdict(dict)
 for r in rows:
  k=r['k']; rep=r.get('rep',r.get('block')); groups[(k,rep)][r['seq']]=r.get('err',r.get('p_err'))
 ds=collections.defaultdict(list)
 for (k,rep),g in groups.items():
  if len(g)==2:ds[k].append(g['B']-g['A'])
 results[name]={k:np.mean(v) for k,v in sorted(ds.items())}
print(results)
# Calibrate affine rule using early evenscan 2-8; transfer as-is to independent archives
x=np.array([2,4,6,8]); y=np.array([results['evenscan'][k] for k in x]); coef=np.polyfit(x,y,1)
print('frozen evenscan early',coef)
rows=[]
for archive,r in results.items():
 for k,obs in r.items():
  pred=float(np.polyval(coef,k)); rows.append([archive,k,obs,pred,obs-pred,archive=='evenscan' and k<=8])
for archive in results:
 rr=[r for r in rows if r[0]==archive and not r[5]]
 print(archive,'n',len(rr),'MAE',np.mean([abs(r[4]) for r in rr]),'mean residual',np.mean([r[4] for r in rr]))
with open(out/'DG_IBM_cross_archive_transfer_2026-10-26.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['archive','k','observed_B_minus_A','frozen_early_even_prediction','residual','training_point']);w.writerows(rows)
# independent linear trend and baseline
for n in results:
 ks=np.array(list(results[n])); vals=np.array(list(results[n].values())); print('fit',n,np.polyfit(ks,vals,1),'delta per k',np.diff(vals)/np.diff(ks))

import numpy as np, json, csv
from scipy.integrate import simpson
alpha=.310 # cycles per ns (310MHz)
rows=[]
for T in (50.,60.,80.,100.):
  for n in (1,2,3):
    tau=(n+.5)/alpha
    if 2*tau>=T: continue
    # envelope defined on [0,T] cosine ramps
    t=np.linspace(0,T,50001)
    f=np.ones_like(t)
    left=t<tau; right=t>T-tau
    f[left]=(1-np.cos(np.pi*t[left]/tau))/2
    f[right]=(1-np.cos(np.pi*(T-t[right])/tau))/2
    F=simpson(f*np.exp(1j*2*np.pi*alpha*t),x=t)
    area=simpson(f,x=t)
    rows.append(dict(T_ns=T,n=n,tau_ns=tau,ratio=tau*alpha,abs_F_ns=abs(F),normalized_F=abs(F)/area))
# test pulse area is T-tau, derivative pi/(2*tau); η theta = pi*(T-tau)/(2*tau*theta) *theta ; normalized area control
assert len(rows)>0
assert max(x['normalized_F'] for x in rows)<1e-9
with open('/mnt/data/DG_NextMaterials_Spectral_Null_Check.csv','w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with open('/mnt/data/DG_NextMaterials_Spectral_Null_Check.json','w') as f: json.dump({'test':'numeric Fourier integral of prescribed envelope, NOT Duffing dynamics or IBM experimental data','alpha_cycles_per_ns':alpha,'max_normalized_residual':max(x['normalized_F'] for x in rows),'cases':rows},f,indent=2)
print(len(rows),max(x['normalized_F'] for x in rows))

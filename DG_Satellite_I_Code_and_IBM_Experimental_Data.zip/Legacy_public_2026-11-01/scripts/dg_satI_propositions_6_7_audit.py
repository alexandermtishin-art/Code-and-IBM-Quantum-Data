import json, math, statistics, csv
from pathlib import Path
base=Path('/mnt/data'); data=json.loads((base/'linear_result(1).json').read_text())['rows']
out=[]
for k in (20,60):
    vals={s:[next(r for r in data if r['k']==k and r['seq']==s and r['block']==b)['counts']['1']/20000 for b in range(6)] for s in ('A','B')}
    d=[v-u for v,u in zip(vals['B'],vals['A'])]
    delta=statistics.mean(d); se=statistics.stdev(d)/math.sqrt(6)
    h=2.570581835636305*se
    loo=[statistics.mean(d[:i]+d[i+1:]) for i in range(6)]
    out.append(dict(k=k,observed_mean_A=statistics.mean(vals['A']),observed_mean_B=statistics.mean(vals['B']),contrast_B_minus_A=delta,observed_two_point_minimax_error=delta/2,conditional_contrast_95_lower=delta-h,conditional_contrast_95_upper=delta+h,conditional_half_lower=(delta-h)/2,conditional_half_upper=(delta+h)/2,min_leave_one_out_contrast=min(loo),max_leave_one_out_contrast=max(loo),blocks_positive=sum(x>0 for x in d)))
with (base/'DG_SatI_Propositions_6_7_quantitative_audit.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=out[0].keys());w.writeheader();w.writerows(out)
for x in out:print(x)

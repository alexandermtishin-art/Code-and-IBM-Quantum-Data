# DG / D reconstruction — research handoff (2026-11-01)

## Current goal
Construct a representation-independent operational mathematical object D from distinguishability and composition, admitting many geometries and with a qubit ultimately only one possible realization; do not postulate a sphere, Hilbert space, Born probabilities, dynamics or HOME.

## Latest selected architecture
Minimal D: preparations S, actions P, contexts C, outputs Y, R, action rho; full-future operational equivalence yields effective X and effective P. With all constant preparations, P recovers X as left-zero elements. With topologized separating responses, an initial topology is obtained, but algebra and separation alone do not determine it. G=U(P), action groupoid X⋊G retains stabilizers. Under proper smooth Lie actions, slice charts G×_H V and gluing cocycles describe geometry as optional *regular equivariant enrichment*, not universal law.

## New 15 KT outcomes
KT01–KT15 in complete autonomous protocol DG_15_Kill_Tests_Nonfree_Actions_2026-10-31.md. Key correction: pair-groupoid comparisons lose isotropy; action groupoid retains it. Equivariant p preserves stabilizer inclusion but arbitrary resets do not. Slice representation and global cocycle are genuinely needed. Hopf vs trivial bundle illustrates global ambiguity.

## Deliverable separation
MAIN compact, claims carefully conditional; SUPPLEMENT detailed S15–S20; GitHub supplemental and selected reproducibility material only, no MAIN; private archive with versions, complete accessible research logs and protocols.

## Open gap
Find physically warranted finite observational certification of topological/slice/cocycle enrichment without circularly assuming full geometry. No new DG-only theorem established yet.

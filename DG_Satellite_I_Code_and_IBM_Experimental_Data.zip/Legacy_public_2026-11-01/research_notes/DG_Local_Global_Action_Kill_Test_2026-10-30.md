# DG: Local rank versus global relations of reversible procedures
Date: 2026-10-30. Internal research note; not inserted in MAIN.

## Scope
Abstract operational quotient X with a separating, symmetric or nonsymmetric divergence D, and a smooth reversible admissible group G acting by D-isometries. The isometry group is shorthand for exact D-preserving bijections; a regular Riemannian metric may be derived in smooth cases. Full state-action equivalence is weaker than full physical procedural equivalence when costs, ancillas or other readouts are admitted.

## Definition
A smooth homomorphism rho: G -> Isom(X,D) has global action kernel K=ker rho={g: rho(g)x=x for all x}. The effective transformation group is G/K. Infinitesimal action at x is theta_x: gLie -> T_xX, theta_x(A)=d/dt|0 rho(exp(tA))x. Its kernel is the Lie algebra of the point stabilizer G_x, not necessarily the Lie algebra of K. For connected G, ker(d rho) = Lie(K), but this cannot reveal discrete K.

## Theorem (kernel criterion; standard group action mathematics)
For g,h in G, rho(g)=rho(h) on all X iff h^{-1}g in K. Thus a word relation w=e in its action iff its interpreted group element lies in K. This does not identify a complete operational procedure relation if response contexts include procedural side effects. The differential of rho detects only Lie(K), leaving discrete kernel unresolved. No new claim of prior-art novelty.

## Constructive witness 1: same local rank / same state metric / different global periods
X=R/Z, D(x,y)=2-2 cos(2 pi(x-y)). Let G=R additive and rho_c(t)(x)=x+c t mod 1 for c nonzero. All preserve D; all have rank-one infinitesimal motion at every x, same local state geometry, and for c=1 versus c=2 have global kernels Z versus (1/2)Z. At t=1/2, rho_1 is half-turn, rho_2 is identity. Even after normalizing velocity by rescaling controls, the physical interpretation of the declared control label matters. The abstract effective groups G/K are both circles, so the difference is in labeled action/period, not intrinsic group isomorphism type.

## Constructive witness 2: identical rank; kernel discrete vs trivial
X=T^2, D=sum_j(2-2cos(2pi(x_j-y_j))). G=R acts by rho_a(t)x=x+t a mod Z^2. For a=(1,0) kernel Z, orbit circles; for a=(1,sqrt(2)) kernel {0}, orbit dense in T^2. At every x the infinitesimal orbit rank is 1, both preserve same D. Global orbit topology and K differ sharply. The exact faithful action has nonclosed dense image in Isom(X,D), consistent with compact X. The group action is not proper. The vector directions differ; witness does not assert identical infinitesimal vectors, only equal rank.

## Important distinction and no-go boundary
Matroid-like closure of infinitesimal operation vectors only recovers dependence relations. It misses periods, lattice kernels, discrete component groups, fundamental-group effects, and stabilizer differences. Requiring exact preservation of every finite word relation is stronger than tangent closure-faithfulness. In full DG physical scope, if action histories carry extra observable effects, define K relative to all instrument contexts, not merely rho on X.

## Next research target
Investigate a two-level realization invariant: (i) closure-faithful infinitesimal representation theta at x for the closure/rank structure, (ii) marked global word congruence on admissible control strings, w≈v iff all admissible continuation and readout contexts coincide. Analyze consistency of word congruence with local theta (integrability, stabilizer, kernel, periodicity), without imposing a unique mechanism. Require explicit nontrivial examples where a proposed compatibility axiom excludes a model; compare to known Lie group action, covering group, operational automata theory before claiming novelty.

## Literature background
MIT 18.755 Lie groups lecture notes, orbit-stabilizer G/G_x and tangent g/g_x; King's College London Lie group actions notes, irrational flow and proper actions; elementary group actions and covering/quotients. These are standard structures. Tulupov-Tishin arXiv:2610.35764: closure faithfulness only after its explicit hypotheses.

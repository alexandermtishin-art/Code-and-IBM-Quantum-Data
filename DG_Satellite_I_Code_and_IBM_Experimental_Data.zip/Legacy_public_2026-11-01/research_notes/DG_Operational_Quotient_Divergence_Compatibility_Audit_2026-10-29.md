# DG Satellite I — compatibility audit: operational quotient and divergence
29 October 2026 | private research note | not a new physics theorem | HOME not used

## Question
May a divergence on fine-grained preparations be regarded unchanged as a DG divergence on the equivalence classes of an incomplete instrument? What constraints do the actual universal DG assumptions place on candidate physical objects without probabilities, Hilbert space or quantum postulates?

## Definitions and exact descent test
Let S be preparations, Q:S→Y a partial observation and x~_Q y iff Q(x)=Q(y). Let D:S×S→[0,∞) be a fine-grained divergence, with D(x,x)=0; if D(x,y)>0 for x≠y, call it separating.

A function Dbar on the quotient S/~_Q exists satisfying Dbar([x],[y])=D(x,y) for all x,y if and only if

  x~_Q x', y~_Q y' ⇒ D(x,y)=D(x',y') .                   (A)

Proof: necessity by evaluating Dbar on the same pair of classes; sufficiency by defining Dbar from any representatives and invoking (A).

If D is separating, (A) forces every Q-fiber to be a singleton: choose x~_Q x', set y=x. The zero diagonal gives D(x',x)=D(x,x)=0, hence x'=x. Therefore **no separating fine-scale divergence can descend unchanged through a genuinely noninjective Q**. This statement applies regardless of any metric regularity.

A DIFFERENT divergence on Q(S) may exist, e.g. D_Q(q,q')=|q-q'|². It is not the original D, and may be smaller in some information orders; its construction and possible data-processing comparison are additional tasks.

## Witness: full versus restricted descriptions
Let S=S², D(x,y)=||x-y||² and Q(x)=x_1. Distinct x=(0,1,0) and y=(0,-1,0) obey Q(x)=Q(y)=0 but D(x,y)=4. If Q defines the **complete** operational state, there cannot be a well-defined Dbar with Dbar(Qx,Qy)=D(x,y). If Q is just one restricted instrument, there is no contradiction: x,y can be distinct full states and Q can miss the difference.

Under available controls {id}, the entire future output signature is equivalent to Q, and the full observational quotient is [-1,1]. Under controls SO(3) with readout Q, the full signature separates S². Thus the two mechanisms do not share identical *complete* operational state spaces; they share the same pre-quotient S, a fine divergence and a limited instrument. This corrects any stronger phrasing in earlier research notes.

## Minimal assumptions and countermodel ledger
(A) Distinguishability/quotient alone does not imply continuity, finite dimension, convexity, three coordinates, ball geometry or a preferred physical semigroup.
(B) A conditional C² nondegenerate Hessian of supplied D gives local metric in a regular manifold sector; it does not by itself imply global Euclidean geometry, compactness or a ball.
(C) D-monotonicity under declared admissible maps restricts each map but does not choose the admissible map family. Identity and rotation families are examples satisfying isometry.
(D) A chosen accessible history and accessibility rate can define length and geometric time along that history; they do not select the history from an abstract control label.
(E) Complete operational quotient in DG v59 is defined through outcome statistics under admissible future procedures; a probability-free event/signature model in this note is a precursor, not a verbatim restatement of v59.

Witness systems (do not claim uniqueness or novelty):
1. S={a,b}, Q injective with distinguishability D=1_{x≠y}, identity/swap; no smooth metric sector.
2. S=S¹, Q embedding into R², Euclidean squared divergence, rotations; smooth one-dimensional regular sector.
3. S=S², Q full embedding, squared Euclidean divergence, rotations; smooth two-dimensional regular sector.
4. S=R, Q=id, D=(x-y)², translations; noncompact regular sector.
All admit operational separation and compositional transformations. The regular examples have different dimensions/topologies. The D formula is chosen, not derived solely from operational separability.

## Consequences
- A newly proposed 'universal DG object' should carry both the **full procedure-relevant quotient** and each **restricted observation map**, never silently interchange them.
- General theorems on quotient descent are elementary and previously known. Their value here is prevention of a circular or inconsistent physics claim, not new mathematical priority.
- For DG Satellite I, define the universal level in terms of admissible signatures, then introduce a nested observer or coarse description Q and a separate physically justified response law. Keep HOME entirely outside premises/results.
- Before asserting DG-specific constraints, obtain and audit the definitive DG v59 text directly; this note relies on version-locked summaries for the precise v59 correspondence, not a fresh line-by-line audit of 74 pages.

## Next positive target
Find a physically justified relation between D and available control/measurement procedures that imposes new constraints beyond (A), ordinary data processing, and known observability/minimization results. If no such result exists, report an honest classification of DG-compatible realizations rather than a novel reconstruction of the qubit.

# DG — Reachability and Directionality (research kill-test)

Date: 2026-10-30. Status: elementary propositions and countermodels, not a claim of new mathematics. Probabilities, quantum formalism, physical time and entropy are not assumed.

## General action
Let a monoid P act on a set X. Define x <= y iff y=p·x for some p∈P. Then <= is reflexive and transitive. The equivalence x≈y iff x<=y and y<=x is a congruence of the preorder (not necessarily a congruence under arbitrary action unless tested); the resulting ordered set X/≈ is a poset. The quotient can lose physical operational distinctions and should not replace the original X unless justified.

## P4 standard action
Let B3 be the Boolean join monoid of subsets of {1,2,3}; P4=N0×B3. With X=N0×B3, action (n,B)·(k,A)=(k+n,A∪B). Then (k,A)<= (l,C) iff k<=l and A⊆C. Antisymmetry holds. H(k,A)=4k+|A| strictly increases along transitions between distinct states, since a positive k step raises H by >=4 and A cannot shrink. The map H is not physical entropy or time; its scale is arbitrary.

## Q4 reset action
On the same X, the generators Xi(k,A)=(k,A∪{i}) and T(k,A)=(k+1,∅). Reachability equals (k,A)<=(l,B) iff either l=k and A⊆B, or l>k (in which case an intervening reset erases restrictions on B). Antisymmetry still holds. H(k,A)=4k+|A| is strictly increasing under state-changing Xi and T: a reset increases H by 4-|A|>=1. This illustrates that losing a record can coexist with an algebraically monotonic scalar; monotonic H is not the same as monotone inclusion of records.

## C4b abstract grading alone does not imply state acyclicity
The same abstract graded monoid P4 can act on X=Z2×B3 by (n,B)·(epsilon,A)=(epsilon+n mod 2,A∪B). Here the tau action gives a two-cycle (0,A)->(1,A)->(0,A) although tau is noninvertible as an element of P4 (no inverse in the full monoid). The action is not faithful: tau² acts as identity, so the effective monoid is Z2×B3 and its positive grading cannot descend. Thus transferring a process grading to a monotonic state invariant requires additional faithfulness/compatibility assumptions. This reduced action is not the complete published P4 operational witness.

## Distinctions
- Invertibility in an abstract monoid differs from invertibility of a particular transformation on X and from thermodynamic irreversibility.
- A preorder quotient X/≈ is a mathematical tool, not automatically the full DG operational quotient.
- A strictly increasing H for one action need not exist for every P4 action, and is neither unique nor a canonical physical clock.
- The standard P4 and reset Q4 constructions show constructive order without probabilities; no arrow of physical time is derived.

## Sources
A. M. Tishin, *Before Geometry: Four-Dimensionality and a Structural Route to Quantum Entanglement from Operational Distinguishability*, Zenodo 10.5281/zenodo.22714203 (2026). N. D. Tulupov and A. M. Tishin, *Compositional Operational Rank, Smooth Realizability, and Dimensional Reduction*, arXiv:2610.35764 (2026).

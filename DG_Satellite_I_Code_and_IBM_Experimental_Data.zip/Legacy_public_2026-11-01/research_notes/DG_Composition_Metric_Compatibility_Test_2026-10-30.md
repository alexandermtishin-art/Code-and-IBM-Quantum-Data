# DG Satellite I — composition–metric compatibility test
Date: 2026-10-30. Research-only; no HOME premises; no qubit assumed.

## Scope
Let E be a finite set of elementary procedures and cl:2^E -> 2^E an extensive, monotone, idempotent closure. A pointwise **closure-faithful linear realization** means vectors v_e in a real tangent space V such that for all A subset E and e in E,

    e in cl(A) iff v_e in span_R{v_a:a in A}.

The operational closure is an additional given structure; this is not a theorem that every physical set of procedures satisfies these closure axioms.

## Necessary obstruction
The represented closure must obey the Steinitz exchange law and all requirements of representability over R (a real-representable vector matroid). Proof: by the iff above, cl is exactly closure by real linear span; such closures are real-representable matroid closures. Consequently an arbitrary algebraic/compositional closure cannot necessarily be embedded faithfully in the tangent geometry, regardless of the divergence.

Counterexample: E={a,b,c}. Define cl(A)=A union {b} if a in A and cl(A)=A otherwise. This is extensive, monotone, idempotent, and cl(empty)=empty. It fails exchange: b in cl({a})\cl(empty), but a not in cl({b}). Suppose v_b belongs to span(v_a). Since b not in cl(empty), v_b neq 0; then v_b=t v_a with nonzero t, so v_a in span(v_b), forcing a in cl({b}), contradiction. No closure-faithful tangent realization exists, even though this closure is valid as an abstract closure operator.

## Sufficient canonical metric realization
If (E,cl) is representable over R by nonzero vectors v_e in R^r (loops can use zero vectors), take X=R^r, divergence D(x,y)=||x-y||^2, procedures T_e^t(x)=x+t v_e for t in R, and measurements Q_j(x)=x_j. Each T_e^t is reversible with inverse T_e^{-t}, compositions are translations, and all preserve D. The tangent vector of T_e^t at t=0 is v_e, so the closure is faithfully realized. D has a regular positive Hessian, and the measurement family separates all states. The construction gives *one* model in the class and does not identify its actual physical realization.

Example U_{2,3}: E={a,b,c}, v_a=(1,0), v_b=(0,1), v_c=(1,1). Pairwise independence and triple dependence agree with linear closure. The Euclidean plane with reversible translations is a DG-compatible realization.

## Logical outcome
For finite E and a pointwise closure-faithful tangent model with free choice of X, Euclidean D and reversible translations, a realization exists iff cl is a real-representable vector-matroid closure. This is a mathematical characterization **for this explicitly defined model class**, not a new DG theorem or proof of physical realizability. It recasts known representability together with a simple canonical Euclidean construction. The source Tulupov–Tishin already includes real representability as a bridge requirement; no novelty is claimed for that condition.

## Limitations and next kill tests
- If allowed transformations are discrete without differentiable one-parameter families, the tangent construction is inapplicable.
- If physical transformations must preserve a *bounded* preparation space, translation on R^r is not an acceptable candidate without alternative constructions.
- Finite-dimensional smooth realization under non-isometric irreversible processes requires further assumptions.
- Dynamics must be selected by an independently specified physical mechanism.
- Abstract closure operator may not match actual compositional closure of physical operations.
- Assess novelty only after checking matroid representation/operational reconstruction literature and exact Tulupov–Tishin hypotheses.

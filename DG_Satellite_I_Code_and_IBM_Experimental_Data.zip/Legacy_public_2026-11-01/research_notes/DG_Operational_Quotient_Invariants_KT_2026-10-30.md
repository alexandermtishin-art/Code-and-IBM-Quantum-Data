# DG — Operational quotient invariants (KT, 2026-10-30)

## Scope
Standard algebraic conclusions and explicit operational countermodels. No probabilities, qubits or HOME.

Let B3 = (P({1,2,3}), union), with identity empty set. The published example P4 = N0 x B3 has product (k,A)(l,B)=(k+l,A union B). Its minimum generator number d(P4)=4: the progress generator tau=(1,empty), plus three Boolean atoms.

## General result
For any surjective monoid homomorphism pi:P→Q, d(Q)≤d(P): images of generators generate. For a fixed labeled elementary set E and closure cl_P(A)=<A>_P, pi(cl_P(A))=cl_Q(pi(A)); but the stronger closure-faithfulness test e∈cl_P(A) iff pi(e)∈cl_Q(pi(A)) need not hold. Injectivity guarantees the test, but its converse is not asserted.

## Three operational quotients

A. Forget progress: pi_A(k,A)=A, onto B3. d(B3)=3. The positive-grade progress generator collapses to identity, so C4b's nontrivial positive grading cannot be inherited. S3 remains on the three atoms.

B. Retain rank, change finite relations: pi_B(k,A)=(k mod 2,A), onto Z2 x B3. d=4, but tau^2 becomes identity, unlike P4. The original positive N0-degree cannot descend. Equal generator count does not preserve global relations.

C. Preserve grading, lose observer richness: h(A)=0 for A empty, h(A)=1 otherwise. Since h(A union B)=max(h(A),h(B)), pi_C(k,A)=(k,h(A)) maps onto N0 x B1. It preserves degree k, but d=2. The S3 permutations descend to a trivial action on the single atom; faithful non-Abelian observer action of C4b is lost. So preservation of grading alone is insufficient.

## Operational realization of each quotient
Take source preparations S=P4, procedures acting by left multiplication, and numeric-free deterministic readout R_pi(s)=pi(s). The entire future response to p is pi(ps)=pi(p)pi(s). Identity continuation is allowed, so equality of all future response profiles is exactly equality of pi(s). The induced effective transformation monoid is the image pi(P4). Importantly these are coarse observation scopes, NOT the fully distinguishing readout in the published P4 witness. No claim to refute its theorem.

## Conclusions and boundaries
Always retained: monoid axioms, image of compositional closure, and a generating set no larger than the original. Not guaranteed: minimal generator count, global relations, source grading, faithful non-Abelian observer richness, C4b, and therefore applicability of the conditional rank-4 theorem. These are established algebraic facts applied to DG construction, not independently novel mathematics.

Sources: Tishin, Before Geometry, Zenodo 22714203; Tulupov and Tishin, arXiv:2610.35764. Standard congruence/quotient semigroup theory.

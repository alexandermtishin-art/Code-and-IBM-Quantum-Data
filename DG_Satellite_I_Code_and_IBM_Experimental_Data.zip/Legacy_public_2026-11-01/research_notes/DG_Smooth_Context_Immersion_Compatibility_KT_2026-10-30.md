# DG smooth-context immersion compatibility — 2026-10-30

## Status
Conditional sufficient criterion, standard differential geometry; *not* a new universal DG theorem. No HOME, no quantum assumptions.

## Assumptions and construction
Let X be a finite-dimensional C² manifold, F=(f₁,…,f_m):X→R^m a C² response map. Define C_F={u·F:||u||₂≤1} and D_F(x,y)=sup_C |f(x)-f(y)|²=||F(x)-F(y)||₂². For admissible T suppose F∘T=A_T F+b_T on F(X), ||A_T||op≤1. Then context closure is ensured when A_Tᵀ maps unit ball to itself, while D_F(Tx,Ty)≤D_F(x,y). (Note closure of the family of *scalar* contexts allows additive constants only if affine constants are included; to avoid this subtlety set b_T=0 or enlarge C_F to all u·F+c with appropriate c.) If inverse also admissible, equality follows by two contractions.

## Local proof
In coordinates y=x+tv+o(t), D_F(x,y)=t²||dF_x v||²+o(t²). Therefore g_x(v,w)=<dF_xv,dF_xw>. Positive definite iff dF_x injective. If θ_x:E→T_xX is closure-faithful, and dF_x is injective on V_x=span θ_x(E), then span dependencies are preserved exactly; thus operational rank is retained. This is sufficient, not claimed necessary absent further restrictions.

## Positive example
X=T², F=(cos x,sin x,cos y,sin y), translations x→x+a,y→y+b represented by orthogonal 2×2 rotations on F. D_F=4 sin²(Δx/2)+4 sin²(Δy/2), g=dx²+dy²; generator images are independent at every x. C_F is stable under precomposition (orthogonal action).

## Negative example
X=S¹, F(φ)=(cos φ,sin³ φ). Injective globally because cos and signed sin³ specify sin uniquely. dF/dφ=(-sinφ, 3 sin²φ cosφ) vanishes at φ=0, π. Consequently D_F separates all points yet g degenerates at those points. This example makes no claim of invariance under full circle translations. A distinct fully context-closed T² example with an L∞-like sup-metric is provided in §6.5 of MAIN and shows failure of a quadratic germ under full translation closure.

## Main takeaway
Smooth immersion of the response map is a sufficient and necessary local criterion for nondegenerate quadratic germ *for this finite Euclidean response construction*. Closure faithfulness is a separate requirement on the operational dependence structure; injectivity of the differential on the operational span preserves its rank. Neither is implied by mere point-separation or context closure. These are known mathematical results deployed as compatibility conditions, not fresh standalone theorems.

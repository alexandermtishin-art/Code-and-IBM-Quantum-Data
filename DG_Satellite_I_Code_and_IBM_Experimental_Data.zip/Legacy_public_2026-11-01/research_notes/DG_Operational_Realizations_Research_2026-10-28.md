# DG operational realizations: first rigorous construction
**Research note — 28 October 2026. Status: established elementary mathematics, novelty NOT demonstrated.**

## 1. Nonprobabilistic framework
Let S be a nonempty set of preparations, P a monoid of admissible deterministic procedures acting on S, C a family of observational contexts, and r_c:S→Y_c their deterministic response signatures. No probabilities, Hilbert space, convex mixtures or quantum dynamics are assumed. Let d_c be a bounded pseudometric on responses (for finite outcomes take d_c(a,b)=1[a≠b]).

For C0⊆C define q_C0(s)=(r_c(s))_{c∈C0}. The operational equivalence s~_C0 t iff all these responses coincide. An operational context is a protocol; the full future class may include composites c∘p and hence is not synonymous with one-time readout.

### Measured future-separation defect
For a physical transformation p∈P and a restricted readout family C0, set
δ_C0(p)= sup { sup_{c∈C0} d_c(r_c(p s),r_c(p t)) : q_C0(s)=q_C0(t)}.
This is bounded when each d_c is. With equal-response pseudometrics, δ=0 iff observational equivalence of C0 is forward stable under p. If δ>0, no deterministic reduced transformation Tbar_p on q_C0(S) can make q_C0∘p=Tbar_p∘q_C0.

**Proof.** If Tbar_p exists, equal q-images remain equal, giving δ=0. Conversely δ=0 means q(ps)=q(pt) for q(s)=q(t), so Tbar_p(q(s)):=q(ps) is well-defined. End.

For a collection P0 of future transformations, δ_C0(P0)=sup_{p∈P0} δ_C0(p) is a quantitative one-step/future closure obstruction. It is NOT a universal dynamical prediction and does not select the transformations.

### Exact-response approximation lower bound
If q(s)=q(t) but the readout responses after p have metric distance Δ, then any common predicted response z obeys max{d(z,r_c(ps)),d(z,r_c(pt))}≥Δ/2 by the triangle inequality. Note that Δ/2 is a lower bound, not generally sharp for arbitrary response metric spaces (no midpoint need exist). A finite measured difference is a bound on recorded data, not automatically on true physical responses.

## 2. Model A: classical finite flip, no probabilities
S={0,1}; P={id,F}, F(0)=1,F(1)=0; r(s)=s with discrete metric. q is injective. δ(F)=0, because there are no distinct states in one q-fiber. Exact evolution is given by the additional rule F, not by indistinguishability alone.

## 3. Model B: direction on a circle, no probabilities
S=S^1; P includes rotations R_θ; choose full operational contexts r_v(n)=v·n for unit vectors v∈S¹. The full signature separates all directions, the quotient supports the physically chosen rotations; for C0={r_x}, q(n)=n_x, two distinct n=(0,+1),(0,-1) have equal q.
For p=R_{π/2}, r_x(p(0,+1))=-1, r_x(p(0,-1))=+1. Taking d(a,b)=|a-b|/2, δ_{r_x}(p)=1. There is no exact autonomous reduced dynamics for x-readout alone. Adding r_y to C0 makes q injective and δ vanish for all rotations. This is a deterministic directional model, not a qubit.

## 4. Model C: three-dimensional orientation / quantum-compatible kinematics
S=S²; P=SO(3), contexts r_v(n)=v·n. All responses are deterministic expectation-like scalar functionals, not interpreted as probabilities. They separate points. This geometrical space can coincide with the *pure* qubit's Bloch direction set after specifying a separate quantum realization map, but this coincidence does not establish the mixed-state ball or Born rule. A classical spin direction satisfies the same S² kinematics.

## 5. Distinct mathematical realizations
Models A and B differ in cardinality/topology of the set of preparations, continuity of reversible groups, and observational structure; no isomorphism preserving these is possible. Both instantiate the same abstract *type* of DG package; they are NOT the same concrete five-tuple with distinct quantum/classical labels. One cannot infer the geometric shape or number of coordinates from a bare operational distinguishing principle.

## 6. Why this is not yet original
Forward-stable observational equivalence is familiar from bisimulation, automata congruences, quotient dynamical systems and sufficient state abstractions. The defect δ is a direct metric witness of their failure; this formulation alone may already have equivalent predecessors. Generalized probabilistic theories treat simplex and ball state spaces, and reconstruction of a qubit from operational principles is well established. The present note does not claim a new object or unique invariant.

## 7. What would be an original next theorem?
Need an additional DG-specific hypothesis not imported ad hoc, such as a defined divergence D with a physically grounded composition/data-processing law, which yields a **nontrivial quantitative bound** on the future-separation defect δ in terms of D and admissible transformation accessibility. Such a statement must withstand tests on the finite flip, circle, sphere, and non-Markov examples; prove whether the bound goes beyond standard data-processing and Lipschitz estimates. Otherwise present it honestly as a known structural criterion applied to DG.

## 8. Consequences for Satellite I
Use generic results in the first part, explicitly with deterministic observation signatures only as a precursor; the extant DG v59 operational equivalence is defined with outcome statistics and must not be misquoted as probability-free. Then instantiate a quantum qubit using ordinary physical probabilities and IBM counts. Theoretical example B is a clean nonprobabilistic demonstration of missing control history, but it does not independently predict numerical IBM errors.

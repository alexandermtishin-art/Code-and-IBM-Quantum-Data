# DG Satellite I — Composition–Geometry Compatibility Kill-Test

Date: 30 October 2026. Research note, **not** a new theorem claim and **not** a change to MAIN.
Scope: DG only; no HOME; no quantum assumptions or probabilities.

## 1. Data and axioms explicitly tested

Take a set X of fully distinguished operational classes, a semigroup P of admissible transformations of X containing identity, and a separating nonnegative divergence D on X×X. Suppose each admissible T obeys the data-processing/contraction condition D(Tx,Ty)≤D(x,y). Assume D is C² near the diagonal in a smooth sector and yields a positive local quadratic metric there. No convexity, probabilistic mixing, specific dimension, or control-to-dynamics law is inferred.

## 2. Reversible part of the semigroup

**Lemma (standard).** If T and T⁻¹ both belong to P and both are D-contractive, then D(Tx,Ty)=D(x,y) for every x,y. Proof: D(x,y)=D(T⁻¹Tx,T⁻¹Ty)≤D(Tx,Ty)≤D(x,y). In the C² regular sector T preserves the induced metric: T* g=g.

Thus the *reversible admissible subgroup* must act by divergence-preserving maps (and metric isometries in the regular sector). This is a genuine constraint of the chosen DG axioms but standard mathematics, not a new DG-specific result.

Crucial qualification: if T is invertible as a set-map but T⁻¹ is **not** physically admissible, equality does not follow.

## 3. Geometry not uniquely selected even by all SO(3) rotations

Let X=S²⊂R³ and G=SO(3) act by rotations. For x,y∈S² set u(x,y)=||x-y||²∈[0,4], and for any a≥0 define

    D_a(x,y)=u(x,y)+a u(x,y)².

All D_a are nonnegative, separating, symmetric, smooth, and G-invariant; composition of allowed rotations preserves all D_a. Near coincidence y=x+v+O(||v||²), with v∈T_x S², u=||v||²+O(||v||³), hence

    D_a(x,y)=||v||²+O(||v||³),

independently of a. Consequently D_a all induce the same local quadratic metric under a fixed convention, yet different finite-separation DG divergences. For antipodal points, D_a(x,−x)=4+16a. This supplies a continuous family of genuinely distinct divergences satisfying the same reversible operational composition and local metric data.

If only divergence-scale is fixed, still a is unrestricted. Thus even the complete SO(3) reversible action and local geometry do not uniquely specify the *global* divergence.

## 4. What symmetry *can* restrict

For the standard transitive action SO(3) on S², an invariant Riemannian metric is unique up to an overall scale, because the stabilizer SO(2) acts irreducibly on the two-dimensional tangent representation. This restriction comes from the **explicitly specified action** plus invariance, not from bare compositional closure or DG distinguishability. It does not fix a global D_a because the family in §3 shares the same metric. With weaker symmetry (e.g. a finite rotation group) the invariant local metrics need not be a single scale family.

## 5. What is and is not learned

PASS: all reversible physically admissible processes with physically admissible inverses preserve D; metric is invariant in its regular sector.

PASS: operation composition plus regularity constrains allowed maps through their common D-isometry group.

FAIL: composition/contraction/regularity selects a unique divergence or a unique state-space dimension.

FAIL: same composition law and full SO(3) action fixes the global D; D_a gives a counterfamily.

NOT TESTED/NOT SHOWN: that physically realizable DG transformations necessarily form a group, are transitive, or are exactly rotations. These require separate empirical or structural premises.

NOVELTY: these are classical properties of nonexpansive maps, invariant metrics, and homogeneous spaces. A future independent DG contribution must add a consequence not already entailed by these principles alone.

## 6. Decision for mathematical-object program

Retain the abstract operational-compositional DG object without importing a quantum mechanism. Record the reversible-subgroup isometry lemma as a **derived consistency condition**, not a headline theorem. Seek additional genuinely DG-specific structural restrictions only where their operational meaning and independence are established. Do not change the MAIN or cite this as a discovered new law.

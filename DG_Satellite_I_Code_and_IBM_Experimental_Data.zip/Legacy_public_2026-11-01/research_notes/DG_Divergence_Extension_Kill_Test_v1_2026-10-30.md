# DG Satellite I — divergence extension of the raw operational object (v1, 30 October 2026)

**Status:** proved model facts, countermodels and open DG-specific question. No HOME, quantum or probability primitives. Do not insert in MAIN as a novelty theorem.

## 1. Data and assumptions

Starting from D0=(S,P,M,Y,r), quotient X=S/~ by equality of all readouts after all admitted transformations. Descended monoid P_X and readouts r_m are well-defined. An additional divergence Δ:X×X→[0,∞) must be specified: Δ(x,x)=0, and (optional but useful) separation Δ(x,y)>0 for x≠y. Data processing is the *additional* requirement Δ(px,py)≤Δ(x,y) for every admitted p. Neither symmetry nor the triangle inequality nor smoothness follows. In DG v59, a local metric requires a separately supplied regular twice differentiable divergence with a nondegenerate quadratic germ on resolved tangent directions. Do not confuse mere membership of Δ in an abstract tuple with its physical calibration.

## 2. Finite countermodel: contracting, separating, non-metric divergence

Let X=Z/3Z, readout r(x)=x, with P={id,c,c²,k_0,k_1,k_2} where c(x)=x+1 mod 3 and k_j(x)=j constant. This is closed under composition; raw observational quotient is X. Define Δ(i,i)=0, Δ(i,i+1 mod 3)=1 and Δ(i,i-1 mod 3)=2. Δ separates points but is asymmetric and is NOT a metric. All c^j preserve Δ and all constants contract Δ to zero. Thus even exact DP and separation do not impose symmetry, unique geometry or a unique physical object. A symmetric alternative Δ'(i,j)=1 for i≠j satisfies the same monoid and readout; the DG divergence is also not uniquely selected by P and r.

## 3. Smooth countermodels: same axioms on different manifolds

Take S=S¹⊂R² with all rotations and readout r(v)=v_1. The readout signature after rotations separates points, hence X=S¹. Choose Δ(v,w)=||v-w||². Rotations are Δ-isometries, and the diagonal Hessian of Δ is positive on the tangent, yielding a regular metric up to the chosen normalization. A distinct smooth example S=S²⊂R³ with SO(3), r(v)=v_1, and the same squared-chordal divergence likewise has a separating full history signature and a positive tangent quadratic germ. Thus smoothness, separation, contraction and reversible group action still do not select intrinsic dimension. All these systems permit deterministic labeled readouts; none needs probabilities.

For every λ>0, Δ_λ=λ Δ on either sphere preserves separation and DP but changes the metric scale. Without a physical normalization, quantitative geometry is underdetermined.

## 4. Strict contraction is not enough either

Adjoin all constant maps to the rotation monoid on a sphere. Constants contract every Δ to zero while rotations preserve Δ; the allowed monoid remains closed. Thus existence of strictly contracting processes cannot fix a particular dimension or eliminate this family of models.

## 5. Positive theorem: operational compatibility condition

If a full-state divergence Δ is required to descend without change through a coarser map Q:X→Z, then Δ(x,y)=\barΔ(Qx,Qy) is possible iff it is constant on all products Q⁻¹(z)×Q⁻¹(z'). In particular, if Δ is separating, any such Q must be injective. This is a standard factorization condition, not DG-specific novelty. A genuinely coarse observer may have its *own* divergence defined from its responses; never carry full Δ down automatically.

## 6. Critical interpretation

Under the enumerated general axioms, adding divergence supplies a class of admissible geometries but cannot distinguish an abstract two-state switch, regular circle, regular sphere or their physically distinct control monoids. It also cannot generate outcome probabilities. These are independence witnesses for the enumerated axioms, NOT an exhaustive independence theorem for every statement in the full DG v59 manuscript.

Potential future substantive theorem: a *non-generic* DG axiom (not simply classical observability, factorization or data processing) that rules out one explicit model while retaining another. Any proposed axiom must be audited against v59 and arXiv:2610.35764 for prior content and against quantum/classical physical counterexamples before claiming novelty. Do not replace the primary goal (construct a mathematical object first, then identify physical specializations including possible qubit) with a unique-law selection project.

# DG — closure of observations under admissible controls
Research note, 28 October 2026. **Not a newly established theorem of physics.**

## The operational construction

Take a set S of preparations, a monoid P of admissible deterministic transformations S→S containing the identity, and an observable readout Q:S→Y. No quantum amplitudes, Hilbert spaces, or probabilities are assumed. Define

    O_P(x) = (Q(Tx))_{T∈P},
    x ≈_P y iff Q(Tx)=Q(Ty) for every T∈P.

This is relative to the selected instrument and permitted controls; it is not necessarily the complete DG operational equivalence when further measurements are admissible.

## Exact statement and proof

1. ≈_P is an equivalence relation.
2. ≈_P refines the original equivalence ker(Q), since the identity is in P.
3. ≈_P is invariant under every U∈P: if x≈_P y, then Ux≈_P Uy. Indeed Q(TUx)=Q(TUy) for all T, because TU∈P.
4. It is the *largest* equivalence relation E⊆ker(Q) that is invariant under every U∈P. If xEy, then for all T∈P, Tx E Ty and hence Q(Tx)=Q(Ty), so x≈_P y.
5. Therefore Q factors into an exactly self-contained controlled prediction model on S/≈_P, with action [x]↦[Ux] and readout [x]↦Q(x). Full original-state distinguishability occurs iff ≈_P is equality, i.e., O_P is injective.

These are standard observable quotient / automata minimization ideas. Their use as DG-compatible, probability-free construction is valid but not itself new mathematics.

## Worked models

A. Two-state switch S={0,1}, full swapping monoid; constant Q=0. Then O_P(0)=O_P(1) forever. Increasing accuracy never resolves the distinction.

B. S=S¹, Q(x,y)=x; P=all planar rotations. For any distinct unit vectors, some rotation gives different x-projections: O_P injective. In fact Q at identity and at π/2 rotation recovers (x,y).

C. S=S², Q(x,y,z)=x; P=rotations about z only. Controlled observations recover x and y, but cannot distinguish (x,y,+z) and (x,y,-z), when both are on S². At poles (0,0,±1), every allowed observation is 0. Thus O_P noninjective.

D. S=S², Q(x,y,z)=x; P=all SO(3) rotations. The three rotations that bring the x-, y-, and z-coordinate to the readout axis suffice to recover all three coordinates, so O_P injective.

## What is established, and what isn't

**Established**: whether controllable readout is complete depends on the *joint* structure of states, controls, and measurement, not device precision alone. A shared general DG language supports all four examples.

**Not established**: DG alone selects P or the realized physical transformation for a control label. No probability-free reconstruction of quantum state space, no DG-specific new invariant, no demonstration that IBM A/B Linear measured controlled observability. Nor does local differential injectivity always imply global injectivity.

## Connection to existing literature

The result is related to observational equivalence, automata minimization, control-system observability, and observation algebras. For precedent see 'A survey on observability of Boolean control networks' (Control Theory and Technology, 2023), https://link.springer.com/article/10.1007/s11768-022-00122-x and 'Local Observability of Systems on Time Scales' (2013), https://onlinelibrary.wiley.com/doi/10.1155/2013/810625 .

## Next true novelty test

Find DG-specific constraints on allowable P, Q and divergence D that exclude some of the operationally legitimate examples or imply a quantitative resolution bound. Otherwise present the theorem as a methodological result and the specific hardware model separately.

# DG divergence versus selection of observable controls
Research audit · 28 October 2026 · not a journal-ready novelty claim

## Question
Does a nonnegative DG distinguishability divergence, its regular metric and contraction under physically admissible transformations determine which controls reveal hidden distinctions in a restricted instrument? We test using no probabilities, Hilbert spaces or quantum assumptions.

## Common operational-geometric substrate
Let S = S² ⊂ R³, D(s,t)=||s−t||², so d_D(s,t)=sqrt(D(s,t)) is chordal distance and the second-order germ induces the standard round tangent metric up to an overall factor. The instrument is Q(s)=s_x ∈[-1,1], with normalized response metric d_Y(a,b)=|a−b|/2. It is Lipschitz: d_Y(Qs,Qt)≤d_D(s,t)/2. Each rotation T∈SO(3) satisfies D(Ts,Tt)=D(s,t), a stronger condition than data processing contraction.

Define δ_Q(T)=sup_{Q(s)=Q(t)} d_Y(Q(Ts),Q(Tt)).

## Result A: same D and Q, opposite prediction-closure behavior
Realization A: physically admissible controls P_A={id}. Then δ_Q(T)=0 for every allowed control; Q supports exact autonomous reduced dynamics. Yet Q is not globally injective.

Realization B: P_B=SO(3). It has the same S,D,Q and satisfies the same isometric divergence law. For T=R_z(π/2), s=(0,1,0), t=(0,-1,0): Q(s)=Q(t)=0, while Q(Ts)=-1 and Q(Tt)=+1. Hence δ_Q(T)=1 (the normalized response diameter is 1). The restricted Q does not support exact dynamics under P_B. Nonetheless the family (Q∘T)_{T∈SO(3)} is injective: rotations may select x, y and z coordinates.

Thus the abstract D and even the demand that *all allowed transformations preserve D* do not select which isometries are physically allowed, nor determine closure of the restricted Q. A positive numerical restriction on δ requires additional relations between the dynamics and Q, or prior control-accessibility information.

## Result B: a valid conditional upper bound, but not DG-specific
Let D induce a metric d_D; let Q:(S,d_D)→(Y,d_Y) be K-Lipschitz; let physical T be L-Lipschitz; let η_Q=sup{d_D(s,t):Q(s)=Q(t)}. Then
δ_Q(T)≤ K L η_Q.
Proof: apply the K and L Lipschitz bounds to each pair in a Q-fiber, then take supremum. If η_Q=∞ the formula is vacuous; if η_Q>0 no strictly vanishing upper bound follows from contraction alone. This inequality is standard metric analysis, not an independent DG theorem.

For the sphere example, η_Q=2 (at Q=0, antipodal points), K=1/2, L=1, so δ≤1. The R_z(π/2) example saturates the bound. The identity control has δ=0 while sharing the same K,L,η.

## Result C: the operationally complete signature changes the problem
With all rotated readouts available, O_P(s)=(Q(Ts))_{T∈P} separates S in Realization B. If one defines *state* as the full operational quotient over all admissible future protocols, then these states are distinct by definition. In Realization A, all future readouts collapse to Q and the quotient is [-1,1]. The common substrate S² is therefore **not** the same full operational quotient in A and B. This distinction matters: one cannot simultaneously claim identical full DG-operational equivalence and different complete future-response signatures. The no-go statement concerns the same **preparation space, divergence, restricted readout, and contraction axiom**, but different admissible-control selections.

## Implication for the manuscript
1. Universality: DG's basic metric/divergence structure constrains admissible processes (e.g. no increase in D under each declared contractive process), but it does not choose the set of physically realized processes.
2. Realization: a control alphabet/semigroup P and its action T must be supplied or derived from extra physical premises. The observer context must also be specified.
3. No numerical hardware inference: the construction does not determine IBM pulse-level schedules, phase response or error rates; no new experiment is reported.
4. Novelty: the no-go and metric bound are known mathematical types (observability, quotient dynamics, data processing, Lipschitz bounds). Their value is a clean logical boundary. To claim novelty, derive an additional restriction **actually entailed by existing DG axioms** and demonstrate it excludes one otherwise allowed realization. Do not postulate the desired bound and rename it a DG result.
5. The DG v59 operational quotient is defined by outcome statistics; this deterministic scalar-response construction is a probability-free *precursor/abstract test model*, not a literal restatement of v59.

## Next discrimination tests
Test additional independently established DG conditions: (i) divergence invariance or monotonicity for composition, (ii) accessibility rate and path length, (iii) local directional structure of supplied histories, (iv) an intrinsic condition connecting the permissible control semigroup to D. If every condition is satisfied by both witnesses, the no-go survives. A positive DG-specific predictive bound requires a genuinely restrictive (iv), with a physical justification.

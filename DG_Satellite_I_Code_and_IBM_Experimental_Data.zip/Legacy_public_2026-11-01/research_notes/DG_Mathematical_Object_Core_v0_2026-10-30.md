# DG Satellite I — candidate mathematical object, core v0 (30 October 2026)

Status: research definitions and elementary deductions; **not** a claim of a new mathematical species or new physical law. Excludes HOME, probabilities, Hilbert space, Bloch ball, quantum postulates.

## D0. Raw objects
A candidate preparation-and-procedure structure is a tuple D0=(S,P,M,Y,r), where S is a nonempty set of preparation descriptions, P is a monoid of physically allowed deterministic preparatory transformations acting on S (the identity and composition are specified), M is a family of readout procedures, Y_m are outcome-label sets, and r_m:S -> Y_m are deterministic observed labels. If instruments have genuinely stochastic outcomes, this deterministic label skeleton is not yet a faithful model of all statistics; no probabilities are assumed in D0.

Write r_{m,p}(s)=r_m(p.s). Define s ~ t iff r_m(p.s)=r_m(p.t) for every p in P and m in M. Define X=S/~.

## Result 1. Operational quotient is dynamically well-defined
~ is an equivalence relation and for every p in P, s~t implies p.s ~ p.t, since for any q in P and any m, r_m(q.p.s)=r_m((qp).s)=r_m((qp).t). Thus the action descends to X. Also the current r_m descends since 1 belongs to P. The signature map X -> product_{p,m}Y_m, [s] -> (r_m(p.s)) is injective. This is a standard observational quotient / Moore-type representation, not a novelty claim.

## Result 2. No geometry, finite dimension, convex mixing or quantum object follows
Example A: S={0,1}, P={identity, flip}, M={m}, r_m(s)=s. The quotient has two points.
Example B: S=S^1, P=SO(2) acting by rotations, M={m}, r_m(cos theta,sin theta)=cos theta. For any distinct unit vectors v,w choose rotation p with distinct first coordinates, so the signature is injective and the quotient is S^1.
These satisfy the same D0 axioms but give nonisomorphic quotients (different cardinality and topology if natural topologies are separately supplied). D0 alone has no topology or dimension at all; assigning a topology in the second example is an extra realization.

## Result 3. Distinguish readout quotient from full state
If Q:S -> Z retains only current readouts, its fibers can be larger than full operational classes. A candidate pair divergence D on X is not automatically a divergence on Q(S). It descends unchanged to a factor only if invariant under independent changes of representatives in both arguments.

## Countermodel to uniqueness of control mechanism
On S^1 use an invariant chordal distance and the readout cosine. Choose P1=SO(2), P2={identity, rotation by pi}. Both preserve chordal distance, but with P2 states theta and -theta have the same cosine for all allowed transformations while P1 separates them (e.g., rotation by pi/2). Thus allowing the same raw preparations, divergence and detector does NOT fix the full operational quotient. Not a failure: the physical mechanism is part of the *realization*.

## Candidate general DG object for research
Only after establishing the raw quotient may one consider D=(X,P,M,r,Delta) with an independently justified divergence Delta on X, subject to chosen data-processing/regularity axioms. Those axioms must be listed separately from D0; do not assume a norm, a metric, an affine mixture, coordinates, a differentiable manifold or SO(3).

## Priority test
Can the exact axioms of DG v59 force a nontrivial restriction on admissible pairs (monoid action, distinguishing procedure family, divergence), beyond observational congruence and ordinary contraction? Need version-locked comparison; a new theorem cannot be announced before this. The arXiv:2610.35764 compositional-rank paper supplies conditional bridges, not a derivation of qubit structure from these axioms.

# DG: compact reversible realizations — kill test (2026-10-30)

## Question
Does compactness/boundedness of preparations, combined with a regular separating divergence and reversible divergence-isometric procedures, impose additional restrictions on *finite closure-faithful tangent representations* of elementary-operation dependence, beyond real representability?

## Definitions and scope
Let E be a finite ground set, cl a closure operator, and suppose there are vectors v_e in R^r such that for every A subset E, e in cl(A) iff v_e in span_R{v_a:a in A}. Here r = dimension span{v_e}; allow loops v_e=0. This is the **pointwise infinitesimal** interpretation of operational dependence, not an identification between algebraic composition of named operations and vector span. Assume differentiable one-parameter controls indexed by e; each t in R gives a physically admissible map T_e^t, including inverses. Compactness means compact smooth connected preparation manifold, not necessarily a convex compact body.

## Proposition A — universal compact model (existing mathematical construction)
Any such real-linear closure representation admits a compact smooth reversible divergence-isometric realization with exactly the same tangent dependence closure at every state.

Proof: take X=T^r=R^r/Z^r with flat metric, and define D([x],[y])=sum_{j=1}^r (2-2 cos(2 pi(x_j-y_j))). This is a smooth nonnegative *separating* divergence (zero iff [x]=[y]), whose Hessian at coincident points is positive definite. Define T_e^t([x])=[x+t v_e]. Well-defined smooth invertible transformations, (T_e^t)^-1=T_e^{-t}; all translations commute, preserve D, and composition is addition of parameters modulo lattice. Their generating vector fields are V_e([x])=v_e (under global parallelization), so the span dependence at every point exactly matches cl. Compactness of T^r is immediate. For r=0 use one-point torus. QED.

**Consequences:** imposing compactness, smoothness, separating regular D, reversibility and full D-isometry alone does not exclude any real-representable finite linear matroid / closure system under this infinitesimal translation-flow interpretation. Non-real-representable closures remain excluded by closure-faithfulness, not by compactness. This does NOT claim all physical operational composition semigroups embed faithfully (actual transformations may exhibit parameter periodicity; see below).

## Proposition B — global group structure is not fixed by tangent closure
Take X=S^1=R/Z, D(u,v)=2-2cos(2pi(u-v)), and one nonzero v. T^t([x])=[x+tv]. Its Lie algebra action is nonzero, but T^{1/v}=identity; hence the R action is nonfaithful, factoring through S^1. More generally finite generators on T^r can have exact periods, integer relations and/or dense cyclic orbits depending on arithmetic data invisible to R-linear span closure. As an illustration with discrete unit-step maps on S^1, translations by 1/2 and by an irrational alpha are both infinitesimally nonzero directions, but the former has finite order 2 and the latter infinite order with dense orbit. These discrete examples are not individually differentiable control families unless extended by t; the full t-flow has a circle image in both cases. Thus tangent closure does NOT determine global composition / return relations.

## Stronger conditional obstruction: faithful additive R^r symmetry
If, in addition, one demands that the action of the full additive group R^r be *faithful, continuous, and proper* by isometries on compact X, this is impossible for r>0: a proper action on compact X has compact acting group (preimage of X times X under the proper action map is G times X, compact); R^r noncompact. Without properness, faithful R action on T^2 by irrational slope flow **is** possible; its image is dense and is not a closed subgroup of Isom(T^2). Therefore 'compactness forbids faithful R action' would be false without additional properness/closed-image assumption. A closed subgroup of Isom(compact Riemannian X) is compact, so a faithful embedded closed additive R^r subgroup is impossible.

## Status and novelty
Proposition A follows from standard torus translation geometry; not a new theorem. Proposition B is classical dynamics. Their novel value for the present investigation is *testing* that boundedness does not strengthen the earlier DG + compositional-rank compatibility criterion without additional assumptions. Do not copy these as novel propositions into MAIN. No qubit or quantum assumptions, no HOME.

## Next test
Ask whether the operational closure is defined on **actual composition words** and physical distinguishability of control maps, rather than only infinitesimal directions. If so, specify whether physical controls have independently measurable finite-order relations and whether control parameter maps must be faithful; then test algebraic (word) relations against compact-isometry group structure. Avoid strengthening axioms solely to force a desired quantum answer.

# DG — Context closure, contraction, and invariant divergence
Date: 2026-10-30. Internal research note; not a new published theorem.

## Scope
No quantum/probability assumptions. Assume a state set X, monoid P of transformations T:X→X, a nonempty family C of real-valued response functions f:X→R. Observables can be generalized to metric outputs via component distances. Assume **forward closure**: for every T∈P and f∈C, f∘T∈C. No assertion this numerical response family follows automatically from qualitative DG without an extra coding/metric choice.

## Exact result 1: canonical supremal pseudodistance
Define d_C(x,y)=sup_{f∈C}|f(x)-f(y)|, possibly +∞. If bounded, this is a pseudometric. Forward closure implies
 d_C(Tx,Ty)=sup_f |(f∘T)(x)-(f∘T)(y)| ≤ d_C(x,y).
If T and T^{-1} both in P (as transformations on X), equality by applying both contractions. If C separates X, d_C(x,y)>0 for x≠y, hence metric; a finite-valued metric when uniformly bounded. Taking D_C=d_C² yields a separating, contractive divergence, but regularity and smoothness NOT automatic; squared metric not globally smooth necessarily.

Alternative D= sup |...|² shares properties. Observational equivalence x~y iff all f(x)=f(y) is invariant under all T, so P descends to X/~ even without numeric metric. If each R_m∘T is another available response, closure holds. For full future continuation contexts, this closure is natural by construction; it is not a new independent postulate when future compositions are included.

## Exact result 2: weighted quadratic divergences need symmetry of weights
For finite C={f_1,...,f_n}, D_w=Σ w_j(f_j(x)-f_j(y))² with w_j>0. If T acts on features via a permutation π_T, invariance follows if weights are π_T-invariant; if not, no general invariance. More generally R(Tx)=A_T R(x)+b_T on response vector: D_W(Tx,Ty)=D_W(x,y) whenever A_T^T W A_T=W. This condition is sufficient, not necessary if response differences span only a proper subspace: equality needed only on the difference set.

Counterexample smooth: X=S¹, R_1(φ)=cos φ,R_2(φ)=sin φ, T:φ↦φ+π/2. The context set {R1,R2} is pullback closed under T and inverse (R1∘T=−R2, R2∘T=R1), IF contexts include signed responses ±R1,±R2, or work with features modulo sign and squared differences; take C={±cos,±sin}, exactly closed. D_w(φ,ψ)=(cosφ−cosψ)²+4(sinφ−sinψ)² (using base 2 features with asymmetric weights). D_w(0,π)=4, D_w(T0,Tπ)=16. Hence closure does not imply invariance of arbitrary weighted D. By contrast D_sym=(cosφ−cosψ)²+(sinφ−sinψ)² is invariant.

## Exact result 3: finite group averaging
For a finite reversible group G acting on X and any separating D0≥0 with D0(x,x)=0, define D_G(x,y)=|G|^{-1}Σ_{g∈G}D0(gx,gy). It is separating (identity term), G-invariant by reindexing. If D0 is a smooth regular response-induced divergence with positive metric, the finite average remains so. Compact topological group: normalized Haar average if integrable and appropriately regular; group-invariance follows. No universal normalized Haar probability for noncompact G.

## Interaction with compositional rank / smooth realizability
If X is a smooth manifold and d_C² is twice differentiable near diagonal with positive-definite Hessian, invertible procedures are isometries of its induced g. Their infinitesimal generators satisfy Killing equation. But d_C based on supremum often nonsmooth, and this regularity cannot be silently inferred. If independently D_w is smooth with an invariant response inner product, the metric g=dR^T W dR is invariant; tangent rank limited by dimension of orbit of the divergence-isometry group at x. Closure-faithfulness from Tulupov–Tishin is extra, not implied by context closure; rank compatibility bounds apply only if physical generators preserve the divergence and span the specified operational directions.

## Novelty assessment and next discriminating test
Facts follow from supremum pseudometrics, semigroup actions, group averages, and equivariant feature maps; no established original theorem. New DG-specific output requires restrictions intrinsic to available physical contexts that narrow invariant divergence or operational-rank embeddings beyond these general results. Test scenarios: finite C with non-permutation pullback matrix; constrained instruments/normalization; whether supremum metric smooth under DG assumptions; group-averaged distance loses quantitative calibration, and hidden instrument weights might be physically fixed and non-invariant.

# DG mathematical object: core and two independent bridges (v1)

## Status
Working formal definition, not yet a novelty theorem or a revision to MAIN. No quantum, probability, metric, or selected dimension is a primitive.

## Core
A deterministic operational-compositional structure is D=(S,P,C,Y,R,rho), where P is a unital monoid, rho:P->End(S) is a monoid action, R:C x S->Y is a family of readouts (not probabilities). Define s~t iff R(c,rho(p)s)=R(c,rho(p)t) for all p,c. Then X=S/~, and the action descends: rho_bar(p)[s]=[rho(p)s]. Proof: s~t implies for every q,c, R(c,rho(q)rho(p)s)=R(c,rho(qp)s)=R(c,rho(qp)t), so rho(p)s~rho(p)t. Note: effect-valued/stochastic procedures not covered by this first deterministic model.

## Key differentiation
The operational future-equivalence quotient X must not be identified without proof with an indistinguishability class [s] used as local bearer for procedure monoids in the d=4 construction. They may have different scopes; explicitly define maps before transferring conclusions.

## Bridge A: Tulupov–Tishin (arXiv:2610.35764)
For a selected finite elementary transition set E and compositional closure cl, the rank r_op is defined at the operational level. Under separate real representability, closure faithfulness on *all subsets*, constant rank, involutivity, and scale compatibility, a local smooth integral leaf can have dimension r_op. A further observer-compatibility assumption is needed to identify measured rank. The bridge does not supply the underlying S, action, readout law, or probability-free observed Fisher rank. For now use only the smooth bridge, not the Fisher stage.

## Bridge B: Tishin Before Geometry, Zenodo 22714203 v2
A selected, finitely generated graded monoid of admissible local procedures satisfying the article's C1,C2,C4a,C4b has minimum generator count n>=4, with pointwise-uniform witness P4=N0 x B3 attaining 4. C3 selects minimal admissible n=4. Atomic-Generation theorem under the paper's further structural requirements identifies this selected generator count with the specified operational distinguishability rank. This is not a bound for arbitrary DG objects, not spacetime dimension, not automatically a Hilbert dimension, and not a derivation of the qubit.

## Critical missing links
1) Relate local procedure monoids P([s]) of the d4 article to the current action monoid P and its operationally distinguishable quotient X (they are not automatically identical).
2) Specify elementary transitions E and compositional closure cl in the current core without assuming finite generation globally.
3) Show whether the d4 witness belongs to the same subclass required for closure-faithful smooth realization; real representability is not automatic from generator number.
4) Choose a response-induced divergence and prove smooth nondegeneracy if a geometric realization is claimed; the supremum over all contexts is often nonsmooth.
5) Separate physical response prediction from state distinguishability: a bare set-valued response cannot supply quantum probabilities.

## New immediate consistency observation
A full future-equivalence quotient X may be trivial even when P is algebraically nontrivial: choose all R(c,s) constant. Thus any nonzero geometric dimension or rank of X requires additional observational separation conditions. Conversely a nontrivial local procedure monoid does not itself enforce rank of X. Proof is immediate from definition.

## Research status
Core defined; quotient action established; literature-sourced conditional bridges available; unique combined theorem and a qubit realization have NOT been established. Continue via precise compatibility between P([s]) and P/X, not a new axiom to force 4.

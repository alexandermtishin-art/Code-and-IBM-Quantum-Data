# DG: operational faithfulness bridge, KT — 2026-10-30

## Scope
This is a mathematical check for deterministic monoid actions; not a universal physical law, nor a new theorem claimed as novel. No probabilities, Hilbert space, preassigned geometry, or qubit assumptions.

Let Q be a monoid acting on S on the left via rho. Let C be observation contexts and R:C×S→Y deterministic. Define s~t iff R(c,rho(u)s)=R(c,rho(u)t) for all c∈C,u∈Q. This is an action congruence: s~t entails rho(p)s~rho(p)t, since u p∈Q. Let X=S/~ and bar rho:Q→End(X).

## Exact criterion
bar rho is injective iff for every distinct p,q∈Q there are s∈S,u∈Q,c∈C with R(c,rho(u p)s) ≠ R(c,rho(u q)s).
Proof: bar rho(p)=bar rho(q) iff for every s, rho(p)s~rho(q)s, iff all the displayed responses agree. Negate.

Consequences: if Q's action is faithful on X, the abstract monoid multiplication and all equalities of words are preserved. For E⊆Q with closure cl(A)=E∩<A> under monoid generation, injection implies e∈cl_Q(A) iff bar rho(e) belongs to the generated submonoid of bar rho(A), intersected with bar rho(E). It does NOT by itself prove a tangent-space closure-faithfulness theorem (which needs separate hypotheses), nor any equality between monoid minimum generator count and state-space dimension.

## Positive witness not reading monoid elements
Q=Z/3Z under addition, S=Z/3Z, action rho(p)s=s+p mod 3. Single binary instrument f(s)=1 iff s=0, otherwise 0. For distinct p,q, prepare s=−p: f(s+p)=1 while f(s+q)=0. No measurement reports the operation label p; one yes/no test suffices with variable preparation. All states operationally distinguishable and action faithful.

## Negative witness: state separation does not imply operation separation
S={0,1}×{0,1}, Q={1,a} where a toggles second coordinate. Single observation f(x,y)=x. Under future actions in Q, observations always x, so X consists of two classes indexed by x. Distinct states in X are perfectly separated, and a acts nontrivially on S, but bar rho(a)=id_X. Thus the operational quotient can erase global algebraic distinctions even when X has multiple observable states.

## Bridge to d=4 manuscript
To apply to local Q=P([s]) from the d=4 preprint, independently verify: (i) local action on a stable admissible domain; (ii) observation contexts with physical meanings and closure under the considered continuations; (iii) pairwise operational separation of every distinct local operation. Only then does the operational realization retain the monoid structure and minimal generator number. The published d=4 result is conditional on its own C1–C4b / C3 and atomic-generation assumptions; none of them automatically supplies pairwise operational separation for a newly selected experimental context family. The Tulupov–Tishin smooth bridge requires real representability, closure-faithfulness, constant rank/involutivity etc.; abstract monoid faithfulness alone is insufficient.

## Novelty / prior-art boundary
The criterion is essentially the definition of faithfulness translated through observational equivalence and known in actions / automata semantics. Its role is to make the missing hypothesis explicit and testable, not to assert independent mathematical novelty.

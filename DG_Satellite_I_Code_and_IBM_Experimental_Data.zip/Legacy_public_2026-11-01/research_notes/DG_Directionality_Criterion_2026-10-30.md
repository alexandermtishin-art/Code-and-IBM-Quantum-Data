# DG: reachability and directional potentials — criterion (30 October 2026)

## Definitions
Let a monoid P act on a set X. Define x <= y iff y=p.x for some p in P. This is a preorder. Let x ~ y iff x<=y and y<=x. The quotient X/~ has an induced partial order. A *strict potential* is H:X -> R with x<=y, x!=y implying H(x)<H(y).

## Criterion 1 (any X)
There exists a strict potential H:X->R only if <= is antisymmetric. Proof: x!=y with x<=y<=x would yield H(x)<H(y)<H(x). Antisymmetry alone is not sufficient for an arbitrary uncountable X (e.g. lexicographically ordered omega_1, which cannot embed strictly into R).

## Criterion 2 (finite X)
The following are equivalent: (a) reachability is antisymmetric; (b) the directed graph of state-changing transitions has no directed cycles; (c) a real/integer strict potential exists. For sufficiency define H(x) to be the maximum number of edges in a directed path from any source to x in the finite acyclic state-change graph (or H(x)=maximum chain length ending at x minus one in the reachability order). Every nontrivial edge increases H.

## Criterion 3 (arbitrary X, weak potential)
The SCC quotient X/~ is always partially ordered by reachability. Therefore directionality of *classes* is automatic, but may be trivial (one class). For any finite quotient, longest-chain height gives integer strict potential on the quotient; lifting is constant on SCCs and is strictly increasing only between different SCCs. For general infinite quotient the existence of a real-valued strict potential is extra.

## Model P4
For the standard left action of P4=N0 x B3 on X=N0 x B3, reachability is (k,A)<=(l,B) iff k<=l and A subset B. H=4k+|A| strictly increases on all nonidentity state changes. Group of units of P4 is trivial, but this is *not* the reason reachability is a partial order: local action and observational scope matter.

## Model Q4 reset action
Let X=N0 x B3, Xi(k,A)=(k,A union {i}), T(k,A)=(k+1,empty). Then H=4k+|A| strictly increases on every state-changing transition. For T, delta H=4-|A|>=1. The initial monoid may be noninvertible while cycles can still occur in other actions (e.g. parity-quotiented P4), demonstrating noninvertibility does not guarantee a strict potential.

## Limits
- Strict H is an order-theoretic monotone, not physical entropy or time.
- Cycles among distinguishable states rule out strict potentials on the original state set but not on its SCC quotient.
- The criterion is standard directed-graph/order theory; not a new DG theorem.
- The paper's definition of physically admissible local domains must be used before declaring its particular relation a monoid action.

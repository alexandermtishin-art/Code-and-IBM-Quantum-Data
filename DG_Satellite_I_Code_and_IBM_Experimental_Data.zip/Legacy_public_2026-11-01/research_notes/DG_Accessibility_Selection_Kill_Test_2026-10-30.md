# DG Satellite I — Kill test: Does accessibility plus geometric time select physical controls?
Date: 2026-10-30. Internal research note; not a theorem of all axioms of DG v59.

## Defined common substrate
S = S² ⊂ R³; D(x,y)=||x-y||²; Q(x)=x₁ is a deliberately restricted instrument. The full operational state is x (when the full accessible probe family separates states); Q is not the full DG quotient. All maps below are reversible Euclidean isometries and preserve D. The regular Hessian of D supplies the ambient Euclidean metric up to conventional factors. For each smooth nonstationary orbit, arc length and a positive calibrated accessibility rate Λ define geometric time dT_G=dℓ/Λ; neither definition selects a generator.

## Three different physically selectable control families
A: SO(2)_x — rotations about x-axis, T_x(θ). Q(T_x(θ)x)=x₁ for all states and θ. Therefore controlled observation Q is not informationally complete: e.g. (0,1,0) and (0,-1,0) always coincide in Q. All transformations are nontrivial on generic preparations.
B: SO(2)_z — rotations about z-axis, T_z(θ). A finite collection of Q after θ=0 and θ=π/2 supplies (x₁,-x₂), but cannot recover sign x₃. For a base preparation x₀=(1,1,1)/√3, both A and B have same nonzero orbit speed |ω|√(2/3) for equal constant angular speed |ω|.
C: SO(3) — all rotations. Selecting three calibrated axes with Q∘T_j measuring x₁,x₂,x₃ gives complete separation of S².

In each case composition, reversibility, metric invariance, nonzero local smooth history, oriented local tangent after choosing the physical control and positive calibrated Λ hold. Yet observer completeness and Q-future responses differ. These conditions alone cannot select whether A, B or C is the actual physical control family. In particular, same D and same Λ do not specify orbit orientation or control-to-generator map. The full set of *admissible future procedures* is different; therefore these are not identical complete operational DG quotients.

## Two distinct faithful/incomplete-scoped interpretations
(1) If admissible procedures means the physical controls and detector available to each model, its *complete* future-response quotient is different between A/B/C. Hence do not claim two models share complete DG states.
(2) If the full state space S is resolved by additional separate possible probes, while the chosen observer only has Q, a shared full state and D are coherent, but the controlled limited-readout task has different accessibility. This makes the example a valid underdetermination witness for structural/metric assumptions, not an independence proof for every v59 clause.

## Research conclusions
- PASS: no unique selectable control family under the enumerated metric, composition, reversibility, nontrivial motion, calibrated rate/time and restricted observation assumptions.
- PASS: physical time and accessibility rates can be assigned consistently after choice of a motion but cannot recover its missing generator.
- FAIL as novelty claim: monotone divergences, factor dynamics and system observability have extensive pre-existing theory; classification of accessibility subgroups and observer orbits is mathematically familiar.
- NOT ESTABLISHED: absolute independence of closure-faithfulness or accessibility from all original DG v59 axioms (requires direct version-locked audit, and the available excerpt is not the entirety of that 74-page manuscript).
- NEXT meaningful possibility: a physically motivated, independently testable selection axiom (not smuggled from HOME or qubit), or a new operational invariant not equivalent to group-orbit separation and standard system observability.

## Known literature analogues
Nielsen-style/Amari information geometry: distinguishability divergences and Markov data-processing. Standard group-actions and observability: group-orbit separation; automata minimality and bisimulation. Wolfer & Watanabe, Geometric aspects of data-processing of Markov chains, Transactions of Mathematics and Its Applications 8(1), 2024, DOI 10.1093/imatrm/tnae001.

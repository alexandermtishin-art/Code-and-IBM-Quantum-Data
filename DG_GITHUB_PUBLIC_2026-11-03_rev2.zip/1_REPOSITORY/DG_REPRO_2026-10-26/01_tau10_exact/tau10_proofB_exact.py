from fractions import Fraction as Q
from collections import defaultdict
import itertools, math, time, sys, json
import numpy as np
import opt_einsum as oe
from pathlib import Path

# ---------- multiindices ----------
def mis(nvar,K):
    out=[]
    for s in range(K+1):
        for tup in itertools.product(range(s+1), repeat=nvar):
            if sum(tup)==s: out.append(tup)
    return out

def leq(a,b): return all(x<=y for x,y in zip(a,b))
def submi(a,b): return tuple(x-y for x,y in zip(a,b))

def zarr(shape):
    a=np.empty(shape,dtype=object); a.fill(Q(0)); return a

def eyeQ(n):
    a=zarr((n,n))
    for i in range(n): a[i,i]=Q(1)
    return a

def matmul(A,B):
    n=A.shape[0]; m=B.shape[1]; k=A.shape[1]
    C=zarr((n,m))
    for i in range(n):
      for j in range(m):
        s=Q(0)
        for q in range(k): s += A[i,q]*B[q,j]
        C[i,j]=s
    return C

def mat_inv(A):
    n=A.shape[0]
    aug=[[Q(A[i,j]) for j in range(n)] + [Q(int(i==j)) for j in range(n)] for i in range(n)]
    for c in range(n):
        piv=next(r for r in range(c,n) if aug[r][c])
        if piv!=c: aug[c],aug[piv]=aug[piv],aug[c]
        p=aug[c][c]
        aug[c]=[x/p for x in aug[c]]
        for r in range(n):
            if r==c: continue
            f=aug[r][c]
            if f:
                aug[r]=[aug[r][j]-f*aug[c][j] for j in range(2*n)]
    out=zarr((n,n))
    for i in range(n):
      for j in range(n): out[i,j]=aug[i][n+j]
    return out

# ---------- truncated bivariate Taylor series about t=1,z=0 ----------
def s_add(A,B,K=6):
    C=dict(A)
    for k,v in B.items():
        if sum(k)<=K:
            C[k]=C.get(k,Q(0))+v
            if not C[k]: C.pop(k,None)
    return C

def s_scale(A,c,K=6): return {k:v*c for k,v in A.items() if v*c and sum(k)<=K}
def s_mul(A,B,K=6):
    C=defaultdict(Q)
    for a,x in A.items():
      for b,y in B.items():
        k=(a[0]+b[0],a[1]+b[1])
        if sum(k)<=K: C[k]+=x*y
    return {k:v for k,v in C.items() if v}

def binomQ(a,n):
    r=Q(1)
    for j in range(n): r*=a-j
    return r/math.factorial(n)

def tpow(a,K=6): return {(n,0):binomQ(a,n) for n in range(K+1) if binomQ(a,n)}
def zpow(n,K=6): return {(0,n):Q(1)} if n<=K else {}

def sinv(A,K=6):
    # assumes A00 != 0
    a0=A.get((0,0),Q(0)); B={(0,0):1/a0}
    allm=mis(2,K)
    for alpha in allm[1:]:
        s=Q(0)
        for beta,av in A.items():
            if beta==(0,0): continue
            if leq(beta,alpha):
                gamma=submi(alpha,beta)
                s += av*B.get(gamma,Q(0))
        B[alpha]=-s/a0
    return {k:v for k,v in B.items() if v}

def taub_metric_jets(b,u,K=6):
    # Kasner exponents p,q,s; Taub Bianchi-II vacuum, point t=1,z=0
    den=Q(1)+u+u*u
    p=-u/den
    q=(Q(1)+u)/den
    s=u*(Q(1)+u)/den
    A2=s_add({(0,0):Q(1)}, s_scale(tpow(4*p,K), b*b,K),K)
    invA2=sinv(A2,K)
    Kx=s_mul(tpow(2*p,K),invA2,K)
    c=s_scale(zpow(1,K),4*p*b,K)
    c2=s_mul(c,c,K)
    gyy=s_add(s_mul(Kx,c2,K), s_mul(tpow(2*q,K),A2,K),K)
    gzz=s_mul(tpow(2*s,K),A2,K)
    gx_y=s_mul(Kx,c,K)
    comps={(0,0):s_scale(A2,Q(-1),K), (1,1):Kx, (1,2):gx_y,(2,1):gx_y,(2,2):gyy,(3,3):gzz}
    out={}
    for alpha in mis(2,K):
        M=zarr((4,4))
        for (i,j),S in comps.items(): M[i,j]=S.get(alpha,Q(0))
        out[alpha]=M
    return out,(p,q,s)

# ---------- metric/tensor Taylor jets ----------
ACTIVE=(0,3)  # coordinates t,z

def deriv_coeff(jets, alpha, coord, active_coords=ACTIVE):
    if coord not in active_coords:
        return zarr(next(iter(jets.values())).shape)
    k=active_coords.index(coord)
    b=list(alpha); b[k]+=1; b=tuple(b)
    if b not in jets: return zarr(next(iter(jets.values())).shape)
    return jets[b]*(alpha[k]+1)

def inv_metric_jets(gj,K):
    zero=(0,0); A0inv=mat_inv(gj[zero]); B={zero:A0inv}
    allm=mis(2,K)
    for alpha in allm[1:]:
        S=zarr((4,4))
        for beta in allm[1:]:
            if sum(beta)>sum(alpha): break
            if leq(beta,alpha):
                gamma=submi(alpha,beta)
                if gamma in B:
                    S += matmul(gj[beta],B[gamma])
        B[alpha]=-matmul(A0inv,S)
    return B

def christoffel_jets(gj,igj,Kout):
    out={}
    for alpha in mis(2,Kout):
        G=zarr((4,4,4))
        for beta,ginv in igj.items():
            if leq(beta,alpha):
                gamma=submi(alpha,beta)
                H=zarr((4,4,4))
                for ss in range(4):
                  for mu in range(4):
                    for nu in range(4):
                      H[ss,mu,nu]=(deriv_coeff(gj,gamma,mu)[ss,nu] + deriv_coeff(gj,gamma,nu)[ss,mu] - deriv_coeff(gj,gamma,ss)[mu,nu])
                # G[r,m,n] += 1/2 ginv[r,s] H[s,m,n]
                G += oe.contract(ginv,[0,1],H,[1,2,3],[0,2,3],optimize='greedy')/2
        out[alpha]=G
    return out

def riemann_jets(Gj,Kout):
    out={}
    for alpha in mis(2,Kout):
        R=zarr((4,4,4,4))
        for rho in range(4):
          for sig in range(4):
            for mu in range(4):
              for nu in range(4):
                R[rho,sig,mu,nu]=deriv_coeff(Gj,alpha,mu)[rho,nu,sig]-deriv_coeff(Gj,alpha,nu)[rho,mu,sig]
        for beta,Gb in Gj.items():
            if leq(beta,alpha):
                gamma=submi(alpha,beta)
                if gamma in Gj:
                    Gc=Gj[gamma]
                    R += oe.contract(Gb,[0,2,4],Gc,[4,3,1],[0,1,2,3],optimize='greedy')
                    R -= oe.contract(Gb,[0,3,4],Gc,[4,2,1],[0,1,2,3],optimize='greedy')
        out[alpha]=R
    return out

def lower_riemann_jets(gj,Rj,Kout):
    out={}
    for alpha in mis(2,Kout):
        T=zarr((4,4,4,4))
        for beta,g in gj.items():
            if leq(beta,alpha):
                gamma=submi(alpha,beta)
                if gamma in Rj:
                    T += oe.contract(g,[0,4],Rj[gamma],[4,1,2,3],[0,1,2,3],optimize='greedy')
        out[alpha]=T
    return out

def cov_derivative_jets(Tj,Gj,Kout):
    rank=next(iter(Tj.values())).ndim
    out={}
    for alpha in mis(2,Kout):
        U=zarr((4,)+next(iter(Tj.values())).shape)
        for e in range(4): U[e]=deriv_coeff(Tj,alpha,e)
        for beta,Gb in Gj.items():
            if leq(beta,alpha):
                gamma=submi(alpha,beta)
                if gamma not in Tj: continue
                Tc=Tj[gamma]
                for e in range(4):
                    Ge=Gb[:,e,:] # p,i
                    for k in range(rank):
                        # integer labels: output axes 0..rank-1; p=rank
                        labs=list(range(rank)); tlabs=labs.copy(); tlabs[k]=rank
                        U[e] -= oe.contract(Ge,[rank,labs[k]],Tc,tlabs,labs,optimize='greedy')
        out[alpha]=U
    return out

def build_taub(b,u,Kmetric=6):
    gj,exps=taub_metric_jets(b,u,Kmetric)
    igj=inv_metric_jets(gj,Kmetric)
    Gj=christoffel_jets(gj,igj,Kmetric-1)
    Rmix=riemann_jets(Gj,Kmetric-2)
    Rcov=lower_riemann_jets(gj,Rmix,Kmetric-2)
    Ds=[Rcov]; T=Rcov; maxjet=Kmetric-2
    for n in range(1,5):
        T=cov_derivative_jets(T,Gj,maxjet-n)
        Ds.append(T)
    return gj,igj,Gj,Rmix,Rcov,Ds,exps

# ---------- exact formal-Pi polynomial ----------
def poly_add(A,B):
    out=dict(A)
    for e,c in B.items():
        out[e]=out.get(e,Q(0))+c
        if not out[e]: del out[e]
    return out

def poly_mul(A,B):
    out=defaultdict(Q)
    for e,c in A.items():
      for f,d in B.items(): out[tuple(x+y for x,y in zip(e,f))]+=c*d
    return {e:c for e,c in out.items() if c}

def polymat_mul(A,B):
    n=len(A); out=[[{} for _ in range(n)] for __ in range(n)]
    for i in range(n):
      for j in range(n):
        s={}
        for k in range(n): s=poly_add(s,poly_mul(A[i][k],B[k][j]))
        out[i][j]=s
    return out

def poly_trace(A):
    s={}
    for i in range(len(A)): s=poly_add(s,A[i][i])
    return s

def trace_word(Js):
    A=Js[0]
    for B in Js[1:]: A=polymat_mul(A,B)
    return poly_trace(A)

def gaussian_moment_counts(ex,cov,memo):
    ex=tuple(ex)
    if sum(ex)==0:return Q(1)
    if sum(ex)%2:return Q(0)
    if ex in memo:return memo[ex]
    i=next(i for i,c in enumerate(ex) if c)
    ex1=list(ex); ex1[i]-=1
    total=Q(0)
    for j,cj in enumerate(ex1):
        if cj:
            ex2=ex1.copy(); ex2[j]-=1
            total += cj*cov[i,j]*gaussian_moment_counts(tuple(ex2),cov,memo)
    memo[ex]=total; return total

def pi_poly(poly,degree,ginv):
    n=degree//2; denom=1
    for j in range(n): denom*=4+2*j
    C=Q((-1)**n,denom); memo={}; tot=Q(0)
    for ex,c in poly.items():
        if sum(ex)==degree: tot += c*gaussian_moment_counts(ex,ginv,memo)
    return C*tot

def Jpoly_from_Dn(Dn,ginv):
    n=Dn.ndim-4; J=[[{} for _ in range(4)] for __ in range(4)]
    for mu in range(4):
      for nu in range(4):
        pol=defaultdict(Q)
        for ders in itertools.product(range(4),repeat=n):
          for rho in range(4):
            gr=ginv[mu,rho]
            if not gr: continue
            for al in range(4):
              for be in range(4):
                val=Dn[ders+(rho,al,nu,be)]
                if val:
                    ex=[0]*4
                    for q in ders: ex[q]+=1
                    ex[al]+=1; ex[be]+=1
                    pol[tuple(ex)] += gr*val
        J[mu][nu]={e:c for e,c in pol.items() if c}
    return J

def F10_exact(Ds0,ginv):
    D0,D1,D3=Ds0[0],Ds0[1],Ds0[3]
    J=Jpoly_from_Dn(D0,ginv); J1=Jpoly_from_Dn(D1,ginv); J3=Jpoly_from_Dn(D3,ginv)
    terms=[(Q(-31,14175),[J,J,J,J,J]),(Q(307,302400),[J,J,J1,J1]),(Q(101,181440),[J,J1,J,J1]),(Q(1,21600),[J,J3,J1]),(Q(1,1814400),[J3,J3])]
    return sum((c*pi_poly(trace_word(word),10,ginv) for c,word in terms),Q(0))

# ---------- invariants ----------
EPS=zarr((4,4,4,4))
for perm in itertools.permutations(range(4)):
    inv=sum(1 for i in range(4) for j in range(i+1,4) if perm[i]>perm[j])
    EPS[perm]=Q(-1 if inv%2 else 1)

def raise_all(T,ginv):
    r=T.ndim
    args=[T,list(range(r))]
    outlabs=[]
    for k in range(r):
        new=r+k; args += [ginv,[k,new]]; outlabs.append(new)
    args += [outlabs]
    return oe.contract(*args,optimize='greedy')

def invs_exact(C,D1,g,ginv,sqrtg):
    Cupall=raise_all(C,ginv)
    I2=oe.contract(C,list(range(4)),Cupall,list(range(4)),[],optimize='greedy')
    Cup2=oe.contract(C,[0,1,4,5],ginv,[4,2],ginv,[5,3],[0,1,2,3],optimize='greedy')
    I3=oe.contract(Cup2,[0,1,2,3],Cup2,[2,3,4,5],Cup2,[4,5,0,1],[],optimize='greedy')
    epsdown=EPS*sqrtg
    eps_ab_upup=oe.contract(epsdown,[0,1,4,5],ginv,[4,2],ginv,[5,3],[0,1,2,3],optimize='greedy')
    starC=oe.contract(eps_ab_upup,[0,1,4,5],C,[4,5,2,3],[0,1,2,3],optimize='greedy')/2
    starCupall=raise_all(starC,ginv)
    P2=oe.contract(C,list(range(4)),starCupall,list(range(4)),[],optimize='greedy')
    starCup2=oe.contract(starC,[0,1,4,5],ginv,[4,2],ginv,[5,3],[0,1,2,3],optimize='greedy')
    P3=oe.contract(Cup2,[0,1,2,3],Cup2,[2,3,4,5],starCup2,[4,5,0,1],[],optimize='greedy')
    D1up=raise_all(D1,ginv)
    grad2=oe.contract(D1,list(range(5)),D1up,list(range(5)),[],optimize='greedy')
    starD1=oe.contract(eps_ab_upup,[1,2,5,6],D1,[0,5,6,3,4],[0,1,2,3,4],optimize='greedy')/2
    starD1up=raise_all(starD1,ginv)
    gradcross=oe.contract(D1,list(range(5)),starD1up,list(range(5)),[],optimize='greedy')
    return I2,I3,P2,P3,grad2,gradcross

# ---------- explicit currents ----------
PATS=[
 {'orders': (0,0,3),'free':(1,0),'pairs':(((2,5),(1,1)),((2,1),(1,2)),((2,4),(0,3)),((2,6),(0,1)),((2,2),(2,0)),((0,2),(2,3)),((1,3),(0,0)))},
 {'orders': (0,0,3),'free':(0,1),'pairs':(((1,0),(2,3)),((0,3),(2,5)),((2,6),(1,2)),((2,4),(1,3)),((2,2),(0,0)),((0,2),(2,1)),((2,0),(1,1)))},
 {'orders': (0,0,3),'free':(1,2),'pairs':(((2,6),(1,3)),((0,0),(2,3)),((2,4),(1,1)),((1,0),(0,3)),((0,2),(2,2)),((2,5),(2,0)),((2,1),(0,1)))},
 {'orders': (0,1,2),'free':(2,3),'pairs':(((0,1),(2,1)),((1,3),(0,3)),((1,0),(2,4)),((1,2),(2,0)),((2,5),(0,0)),((1,1),(0,2)),((2,2),(1,4)))},
 {'orders': (0,1,2),'free':(2,5),'pairs':(((2,0),(1,1)),((2,2),(0,2)),((2,3),(1,3)),((1,4),(2,4)),((1,0),(0,1)),((0,0),(2,1)),((1,2),(0,3)))},
 {'orders': (0,1,2),'free':(1,1),'pairs':(((1,3),(0,2)),((0,1),(2,0)),((0,3),(2,3)),((2,1),(1,2)),((2,5),(1,0)),((2,4),(1,4)),((2,2),(0,0)))},
 {'orders': (2,3),'free':(1,0),'pairs':(((1,4),(0,5)),((0,2),(1,5)),((1,3),(0,1)),((0,3),(1,1)),((1,6),(0,4)),((0,0),(1,2)))},
]

def contraction_pairs(tensors,pairs,ginv):
    # unique label for every tensor axis, plus metric factors pairing labels
    labels=[]; nxt=0
    for T in tensors:
        labs=list(range(nxt,nxt+T.ndim)); nxt+=T.ndim; labels.append(labs)
    args=[]
    for T,labs in zip(tensors,labels): args += [T,labs]
    for (fa,aa),(fb,ab) in pairs:
        args += [ginv,[labels[fa][aa],labels[fb][ab]]]
    args += [[]]
    return oe.contract(*args,optimize='greedy')

def divergence_pattern(pattern,Ds,ginv):
    total=Q(0); orders=pattern['orders']; free=pattern['free']; oldpairs=pattern['pairs']
    for j in range(len(orders)):
        tensors=[]
        for i,o in enumerate(orders): tensors.append(Ds[o+1] if i==j else Ds[o])
        def shift(A):
            f,a=A; return (f,a+1) if f==j else (f,a)
        pairs=[(shift(A),shift(B)) for A,B in oldpairs]
        pairs.append(((j,0),shift(free)))
        total += contraction_pairs(tensors,pairs,ginv)
    return total

# ---------- row ----------
def ricci_from_Rmix(R):
    Ric=zarr((4,4))
    for s in range(4):
      for n in range(4):
        Ric[s,n]=sum((R[r,s,r,n] for r in range(4)),Q(0))
    return Ric

def eval_taub(b,u,verbose=False):
    t0=time.time(); gj,igj,Gj,Rmix,Rcov,Dsj,exps=build_taub(b,u,6)
    zero=(0,0); g=gj[zero]; gi=igj[zero]; Ds=[T[zero] for T in Dsj]
    Ric=ricci_from_Rmix(Rmix[zero]); ric0=all(x==0 for x in Ric.flat)
    sqrtg=Q(1)+b*b  # at t=1
    inv=invs_exact(Ds[0],Ds[1],g,gi,sqrtg)
    I2,I3,P2,P3,grad2,gradcross=inv
    Qs=[I2*I3,P2*P3,I2*grad2,P2*gradcross]
    F=F10_exact(Ds,gi)
    Dsdiv=[divergence_pattern(p,Ds,gi) for p in PATS]
    cand=(Q(106781)*Qs[0]+Q(49431)*Qs[1]+Q(2187)*Qs[2]-Q(867)*Qs[3])/Q(55738368000)
    res=F-cand
    if verbose:
        print('exps',exps,'ric0',ric0,'sqrtg',sqrtg,'time',round(time.time()-t0,3))
        print('invs',inv);print('F',F);print('Q',Qs);print('D',Dsdiv);print('cand',cand,'res',res)
    return {'b':b,'u':u,'exps':exps,'ricci_zero':ric0,'sqrtg':sqrtg,'invs':inv,'F':F,'Q':Qs,'D':Dsdiv,'candidate':cand,'residual':res,'seconds':time.time()-t0}

# Frozen exact-proof probes: one Taub/Bianchi-II family with fixed Kasner parameter u=2.
_BS=[Q(1,3),Q(1,4),Q(1,5),Q(2,5),Q(1,2),Q(2,7),Q(3,7),Q(3,8),Q(4,9),Q(2,9),Q(5,11),Q(3,10)]
TAUBS=[(b,Q(2)) for b in _BS]

if __name__=='__main__':
    idx=int(sys.argv[1]) if len(sys.argv)>1 else 0
    r=eval_taub(*TAUBS[idx],verbose=True)
    # json-friendly exact strings
    out={k:([str(x) for x in v] if isinstance(v,list) else str(v) if isinstance(v,Q) else v) for k,v in r.items() if k not in ('invs','exps')}
    out['invs']=[str(x) for x in r['invs']]; out['exps']=[str(x) for x in r['exps']]
    with open(Path(__file__).resolve().parent / f'tau10_exact_taub_{idx:02d}.json','w') as f: json.dump(out,f,indent=2)

import sys,json,time
from pathlib import Path
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
from tau10_proofB_exact import eval_taub,Q
bs=[Q(1,3),Q(1,4),Q(1,5),Q(2,5),Q(1,2),Q(2,7),Q(3,7),Q(3,8),Q(4,9),Q(2,9),Q(5,11),Q(3,10)]
inds=[int(x) for x in sys.argv[1:]] if len(sys.argv)>1 else list(range(11))
for i in inds:
    t=time.time(); r=eval_taub(bs[i],Q(2),False)
    def conv(v):
        import numpy as np
        if isinstance(v,np.ndarray):
            if v.ndim==0: return conv(v.item())
            return [conv(x) for x in v.tolist()]
        if isinstance(v,Q): return str(v)
        if isinstance(v,(list,tuple)): return [conv(x) for x in v]
        return v
    out={k:conv(v) for k,v in r.items()}
    with open(BASE / f'tau10_exact_taub_{i:02d}.json','w') as f: json.dump(out,f,indent=2)
    print(f'ROW {i} b={bs[i]} ricci={r["ricci_zero"]} sec={time.time()-t:.2f} res={r["residual"]}',flush=True)

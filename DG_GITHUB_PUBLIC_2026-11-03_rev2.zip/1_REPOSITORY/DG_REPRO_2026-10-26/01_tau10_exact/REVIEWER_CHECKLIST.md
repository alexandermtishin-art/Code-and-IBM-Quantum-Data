# Reviewer checklist for the DG τ^10 5→4 certificate

For an adversarial audit, the following checks are intentionally separable.

1. **Raw Jacobi algebra**
   - Run `python DG_tau10_exact_audit.py`.
   - Verify the exact raw-14 minus five-term identity is a total τ derivative.

2. **Local-space dimension**
   - Run `python tau10_PROOF_A_spinor_count.py`.
   - Verify `dim S_even(10)=11` and `dim V_even(9)=8`.
   - Inspect `tau10_PROOF_A_B0_spinor_basis.md` for the channel decomposition.

3. **No current reselection**
   - Inspect the seven frozen `CURRENT_PATTERNS` in `tau10_proofB_exact.py`.
   - Compare them with Section 3 of `tau10_PROOF_B_exact_proof.md`.

4. **Exact basis certificate**
   - Run `python solve_tau10_exact.py`.
   - Verify `rank(B)=11`, exact determinant ≠ 0, and `det mod 1000003=895554`.
   - Verify the first four coordinates of the residual are exactly zero.

5. **Withheld veto**
   - Confirm row 11 (`b=3/10`) is not among the 11 rows used for the determinant.
   - Confirm its raw residual is nonzero.
   - Confirm `residual - Σ alpha_i D_i = 0` exactly.

6. **Convention lock**
   - With full dependencies installed, run `python tau10_PROOF_B_convention_lock.py`.
   - Verify all three formal-Π identities at a Taub point with nonzero pseudoscalars.

7. **Full regeneration**
   - Run `python verify_tau10.py --full`.
   - This overwrites the archived row JSON files from the metric/tensor-jet engine
     and then repeats the exact solve.

8. **Logical point to attack**
   - The finite evaluation step is valid only because the 11-dimensional local
     scalar-space theorem is established independently and the 11 displayed
     columns are elements of that same space. Any objection should therefore
     target either that dimension theorem, membership of a displayed current/
     quotient structure in the stated space, or an implementation/convention
     error in the exact evaluator—not generic objections to finite background fitting.

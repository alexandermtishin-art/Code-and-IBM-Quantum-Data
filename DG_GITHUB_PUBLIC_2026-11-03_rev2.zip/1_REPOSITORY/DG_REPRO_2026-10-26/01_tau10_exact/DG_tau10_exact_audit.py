#!/usr/bin/env python3
"""Exact-arithmetic audit for the DG Jacobi/Riccati hierarchy.

Checks, without floating point:
  1. The 14-term pointwise tau^10 coefficient differs from the 5-term
     cyclic/1D-IBP representative by dF9/dtau exactly.
  2. A convention-lock Weyl benchmark E=diag(-2,1,1), B=0 gives
       I2=48, I3=96,
       Pi tr J^3 = -3/2 = -I3/64,
       Pi tr J^4 = 27/5 = (6 I2^2)/2560,
       Pi tr J^5 = -6 = -(8 I2 I3)/6144.

Only Python standard library is required.
"""
from fractions import Fraction as Q
from collections import defaultdict
from itertools import product

# ---------- cyclic trace-word algebra ----------
def cyc(word):
    word = tuple(word)
    if len(word) <= 1:
        return word
    rots = [word[i:] + word[:i] for i in range(len(word))]
    return min(rots)

def add_term(expr, coeff, word):
    w = cyc(tuple(word))
    expr[w] += Q(coeff)
    if expr[w] == 0:
        del expr[w]

def derivative(expr):
    out = defaultdict(Q)
    for word, coeff in expr.items():
        for i in range(len(word)):
            w = list(word)
            w[i] += 1
            add_term(out, coeff, w)
    return out

def subtract(a, b):
    out = defaultdict(Q)
    for w,c in a.items(): add_term(out,c,w)
    for w,c in b.items(): add_term(out,-c,w)
    return out

raw = defaultdict(Q)
for c,w in [
    (Q(-31,14175),(0,0,0,0,0)),
    (Q(-47,181440),(0,1,3)),
    (Q(-47,181440),(0,3,1)),
    (Q(-2279,907200),(0,0,1,1)),
    (Q(-73,60480),(0,1,0,1)),
    (Q(-1,51840),(3,3)),
    (Q(-1,2025),(1,1,2)),
    (Q(-1,567),(0,0,0,2)),
    (Q(-19,56700),(0,2,2)),
    (Q(-13,113400),(0,0,4)),
    (Q(-1,32400),(2,4)),
    (Q(-1,64800),(1,5)),
    (Q(-1,226800),(0,6)),
    (Q(-1,3628800),(8,)),
]: add_term(raw,c,w)

five = defaultdict(Q)
for c,w in [
    (Q(-31,14175),(0,0,0,0,0)),
    (Q(307,302400),(0,0,1,1)),
    (Q(101,181440),(0,1,0,1)),
    (Q(1,21600),(0,3,1)),
    (Q(1,1814400),(3,3)),
]: add_term(five,c,w)

F9 = defaultdict(Q)
for c,w in [
    (Q(-1,3628800),(7,)),
    (Q(-1,226800),(0,5)),
    (Q(-1,90720),(1,4)),
    (Q(-1,50400),(2,3)),
    (Q(-13,113400),(0,0,3)),
    (Q(-131,907200),(0,1,2)),
    (Q(-173,907200),(0,2,1)),
    (Q(-1,18900),(1,1,1)),
    (Q(-1,567),(0,0,0,1)),
]: add_term(F9,c,w)

ibp_residual = subtract(subtract(raw,five), derivative(F9))
assert not ibp_residual, f"14->5 identity failed: {dict(ibp_residual)}"
print("PASS 1: Theta10_raw - Theta10_5 = dF9/dtau exactly (cyclic trace algebra).")

# ---------- exact formal-Pi normalization lock ----------
# Lorentz signature (-,+,+,+), purely electric Weyl E=diag(-2,1,1), B=0.
eta = (-1,1,1,1)
E = ((-2,0,0),(0,1,0),(0,0,1))
C = defaultdict(int)

def eps3(i,j,k):
    if len({i,j,k}) < 3: return 0
    p=(i,j,k)
    inv=sum(p[a] > p[b] for a in range(3) for b in range(a+1,3))
    return -1 if inv%2 else 1

def set_riem(a,b,c,d,val):
    if val == 0: return
    for aa,bb,s1 in ((a,b,1),(b,a,-1)):
        for cc,dd,s2 in ((c,d,1),(d,c,-1)):
            C[(aa,bb,cc,dd)] = s1*s2*val
            C[(cc,dd,aa,bb)] = s1*s2*val

for i in range(3):
    for j in range(3):
        set_riem(0,i+1,0,j+1,E[i][j])
for i,j,k,l in product(range(3), repeat=4):
    val = -sum(eps3(i,j,m)*eps3(k,l,n)*E[m][n]
               for m,n in product(range(3), repeat=2))
    set_riem(i+1,j+1,k+1,l+1,val)

def cv(a,b,c,d): return C.get((a,b,c,d),0)

I2 = 0
for a,b,c,d in product(range(4), repeat=4):
    I2 += cv(a,b,c,d)*cv(a,b,c,d)*eta[a]*eta[b]*eta[c]*eta[d]

# C_ab^{cd}
Cup = {}
for a,b,c,d in product(range(4), repeat=4):
    Cup[(a,b,c,d)] = cv(a,b,c,d)*eta[c]*eta[d]
I3 = 0
for a,b,c,d,e,f in product(range(4), repeat=6):
    I3 += Cup[(a,b,c,d)]*Cup[(c,d,e,f)]*Cup[(e,f,a,b)]

assert I2 == 48 and I3 == 96, (I2,I3)

# Polynomial in u0..u3 represented by {exponent_tuple: rational coefficient}.
def padd(p,q):
    r=defaultdict(Q)
    for m,c in p.items(): r[m]+=c
    for m,c in q.items(): r[m]+=c
    return {m:c for m,c in r.items() if c}

def pmul(p,q):
    r=defaultdict(Q)
    for a,ca in p.items():
        for b,cb in q.items():
            r[tuple(x+y for x,y in zip(a,b))] += ca*cb
    return dict(r)

def matmul(A,B):
    n=4
    M=[[{} for _ in range(n)] for __ in range(n)]
    for i in range(n):
        for j in range(n):
            r={}
            for k in range(n): r=padd(r,pmul(A[i][k],B[k][j]))
            M[i][j]=r
    return M

# J^mu_nu = C^mu_{ alpha nu beta} u^alpha u^beta
J=[[{} for _ in range(4)] for __ in range(4)]
for mu in range(4):
    for nu in range(4):
        p=defaultdict(Q)
        for al,be in product(range(4), repeat=2):
            val=eta[mu]*cv(mu,al,nu,be)
            if val:
                ex=[0]*4; ex[al]+=1; ex[be]+=1
                p[tuple(ex)] += Q(val)
        J[mu][nu]=dict(p)

def trace_power(k):
    P=J
    for _ in range(k-1): P=matmul(P,J)
    r={}
    for i in range(4): r=padd(r,P[i][i])
    return r

def odd_double_factor_for_even_exp(e):
    # number of pairings of e identical slots = (e-1)!!, e even
    if e==0: return 1
    out=1
    for x in range(1,e,2): out*=x
    return out

def pi_even_poly(poly, degree):
    n=degree//2
    denom=1
    for j in range(n): denom *= (4+2*j)
    C2n=Q((-1)**n,denom)  # c=1, d=4
    total=Q(0)
    for ex,coef in poly.items():
        if sum(ex)!=degree or any(e%2 for e in ex): continue
        pairing=1
        sign=1
        for i,e in enumerate(ex):
            pairing *= odd_double_factor_for_even_exp(e)
            if eta[i] == -1: sign *= (-1)**(e//2)
        total += coef*pairing*sign
    return C2n*total

pi3=pi_even_poly(trace_power(3),6)
pi4=pi_even_poly(trace_power(4),8)
pi5=pi_even_poly(trace_power(5),10)
assert pi3 == Q(-3,2) == Q(-1,64)*I3
assert pi4 == Q(27,5) == Q(1,2560)*6*I2*I2
assert pi5 == Q(-6,1) == Q(-1,6144)*8*I2*I3
print("PASS 2: normalization lock I2=48, I3=96, P2=P3=0.")
print("        Pi tr J^3 =", pi3, "= -I3/64")
print("        Pi tr J^4 =", pi4, "= 6 I2^2/2560")
print("        Pi tr J^5 =", pi5, "= -8 I2 I3/6144")
print("ALL EXACT AUDIT CHECKS PASSED.")

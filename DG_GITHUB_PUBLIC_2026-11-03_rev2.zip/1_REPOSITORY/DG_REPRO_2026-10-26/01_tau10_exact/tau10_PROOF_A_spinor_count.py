#!/usr/bin/env python3
"""
Exact representation-theory certificate for the 4D Ricci-flat Weyl-jet count
at mass dimension 10, before spacetime integration by parts.

No floating-point arithmetic is used.
"""
from collections import Counter, defaultdict

MAX_N = 7

def irrep_weights(a, b):
    return [(i, j)
            for i in range(-a, a + 1, 2)
            for j in range(-b, b + 1, 2)]

def sym_power_char(a, b, m):
    dp = {(0, 0, 0): 1}
    for wx, wy in irrep_weights(a, b):
        nd = dict(dp)
        for (k, x, y), c in list(dp.items()):
            for r in range(1, m - k + 1):
                key = (k + r, x + r * wx, y + r * wy)
                nd[key] = nd.get(key, 0) + c
        dp = nd
    return {(x, y): c for (k, x, y), c in dp.items() if k == m}

def multiply_chars(chars):
    out = {(0, 0): 1}
    for ch in chars:
        nd = defaultdict(int)
        for (x, y), c in out.items():
            for (u, v), d in ch.items():
                nd[(x + u, y + v)] += c * d
        out = dict(nd)
    return out

def decompose_char(ch):
    ch = Counter({k: v for k, v in ch.items() if v})
    reps = Counter()
    while ch:
        candidates = [(w, c) for w, c in ch.items()
                      if c > 0 and w[0] >= 0 and w[1] >= 0]
        if not candidates:
            raise RuntimeError("Character decomposition failed.")
        (a, b), mult = max(
            candidates,
            key=lambda z: (z[0][0] + z[0][1], z[0][0], z[0][1])
        )
        reps[(a, b)] += mult
        for wt in irrep_weights(a, b):
            ch[wt] -= mult
            if ch[wt] == 0:
                del ch[wt]
            elif ch[wt] < 0:
                raise RuntimeError("Negative residual weight multiplicity.")
    return reps

# chirality, jet level n, doubled jL, doubled jR, mass dimension
types = []
for n in range(MAX_N + 1):
    types.append(("L", n, 4 + n, n, 2 + n))
    types.append(("R", n, n, 4 + n, 2 + n))

type_order = {(t[0], t[1]): i for i, t in enumerate(types)}
sym_cache = {}

def char_for_mults(ms):
    chars = []
    for t, m in zip(types, ms):
        if m:
            key = (t[2], t[3], m)
            if key not in sym_cache:
                sym_cache[key] = sym_power_char(t[2], t[3], m)
            chars.append(sym_cache[key])
    return multiply_chars(chars)

def enumerate_multisets(total_dim):
    sols = []
    def rec(idx, remaining, cur):
        if idx == len(types):
            if remaining == 0:
                sols.append(tuple(cur))
            return
        d = types[idx][4]
        for m in range(remaining // d + 1):
            cur.append(m)
            rec(idx + 1, remaining - m * d, cur)
            cur.pop()
    rec(0, total_dim, [])
    return sols

def descriptor(ms):
    return tuple((t[0], t[1], m) for t, m in zip(types, ms) if m)

def parity_descriptor(desc):
    mapped = [
        (("R" if ch == "L" else "L"), n, m)
        for ch, n, m in desc
    ]
    return tuple(sorted(mapped, key=lambda x: type_order[(x[0], x[1])]))

# ---------- dimension-10 scalars ----------
scalar_rows = []
for ms in enumerate_multisets(10):
    reps = decompose_char(char_for_mults(ms))
    mult = reps.get((0, 0), 0)
    if mult:
        nf = sum(ms)
        deriv = sum(ms[i] * types[i][1] for i in range(len(types)))
        scalar_rows.append((nf, deriv, mult, descriptor(ms)))

by_desc = {r[3]: r for r in scalar_rows}
seen = set()
even_scalar = 0
odd_scalar = 0
sector_even = Counter()

for nf, deriv, mult, desc in scalar_rows:
    if desc in seen:
        continue
    pdesc = parity_descriptor(desc)
    if pdesc == desc:
        # At this order the unique self-conjugate scalar channel is
        # L0 R0 L1 R1, whose unique real contraction is parity even.
        even_scalar += mult
        sector_even[(nf, deriv)] += mult
        seen.add(desc)
    else:
        pmult = by_desc[pdesc][2]
        if pmult != mult:
            raise RuntimeError("Parity-paired scalar multiplicities disagree.")
        even_scalar += mult
        odd_scalar += mult
        sector_even[(nf, deriv)] += mult
        seen.add(desc)
        seen.add(pdesc)

# ---------- dimension-9 vector currents ----------
vector_rows = []
for ms in enumerate_multisets(9):
    reps = decompose_char(char_for_mults(ms))
    mult = reps.get((1, 1), 0)  # Lorentz vector (1/2,1/2)
    if mult:
        nf = sum(ms)
        deriv = sum(ms[i] * types[i][1] for i in range(len(types)))
        vector_rows.append((nf, deriv, mult, descriptor(ms)))

by_vdesc = {r[3]: r for r in vector_rows}
seen = set()
even_vector = 0
sector_vector_even = Counter()

for nf, deriv, mult, desc in vector_rows:
    if desc in seen:
        continue
    pdesc = parity_descriptor(desc)
    if pdesc == desc:
        raise RuntimeError("Unexpected self-parity vector channel.")
    pmult = by_vdesc[pdesc][2]
    if pmult != mult:
        raise RuntimeError("Parity-paired vector multiplicities disagree.")
    even_vector += mult
    sector_vector_even[(nf, deriv)] += mult
    seen.add(desc)
    seen.add(pdesc)

print("=== PROOF A: local parity-even scalars at mass dimension 10 ===")
print("complex Lorentz-scalar multiplicity =", sum(r[2] for r in scalar_rows))
print("parity-even dimension =", even_scalar)
print("parity-odd dimension  =", odd_scalar)
for key in sorted(sector_even, key=lambda k: (k[0], -k[1])):
    nf, deriv = key
    print(f"C^{nf} D^{deriv}: {sector_even[key]}")
assert even_scalar == 11
assert odd_scalar == 10
assert sector_even[(2, 6)] == 1
assert sector_even[(3, 4)] == 3
assert sector_even[(4, 2)] == 5
assert sector_even[(5, 0)] == 2

print()
print("=== Dimension-9 parity-even Lorentz-vector currents ===")
print("parity-even current dimension =", even_vector)
for key in sorted(sector_vector_even, key=lambda k: (k[0], -k[1])):
    nf, deriv = key
    print(f"C^{nf} D^{deriv}: {sector_vector_even[key]}")
assert even_vector == 8
assert sector_vector_even[(2, 5)] == 1
assert sector_vector_even[(3, 3)] == 4
assert sector_vector_even[(4, 1)] == 3

print()
print("CERTIFICATE: PASS")

from fractions import Fraction as F
import json, math
from pathlib import Path
BASE=Path(__file__).resolve().parent
P=1000003

def parse(x):
    if isinstance(x,str): return F(x)
    if isinstance(x,list): return [parse(y) for y in x]
    return x
rows=[]
for i in range(11):
    d=json.load(open(BASE / f'tau10_exact_taub_{i:02d}.json'))
    d={k:parse(v) for k,v in d.items()}
    rows.append(d)
assert all(r['ricci_zero'] for r in rows)
B=[r['Q']+r['D'] for r in rows]
res=[r['residual'] for r in rows]
withheld_raw=json.load(open(BASE / 'tau10_exact_taub_11.json'))
withheld={k:parse(v) for k,v in withheld_raw.items()}
assert withheld['ricci_zero']

def qmod(q,p=P): return (q.numerator%p)*pow(q.denominator%p,-1,p)%p

def rank_det_mod(A,p=P,return_piv=False):
    M=[[qmod(x,p) for x in row] for row in A]
    m=len(M); n=len(M[0]); rank=0; det=1; swaps=0; pivots=[]
    for c in range(n):
        piv=next((r for r in range(rank,m) if M[r][c]%p),None)
        if piv is None: continue
        if piv!=rank: M[rank],M[piv]=M[piv],M[rank]; swaps+=1
        pv=M[rank][c]%p; pivots.append((rank,c,pv)); det=det*pv%p
        inv=pow(pv,-1,p)
        # normalize pivot row for elimination convenience
        for j in range(c,n): M[rank][j]=M[rank][j]*inv%p
        for r in range(rank+1,m):
            f=M[r][c]%p
            if f:
                for j in range(c,n): M[r][j]=(M[r][j]-f*M[rank][j])%p
        rank+=1
        if rank==m: break
    if m==n and rank==n:
        if swaps%2: det=(-det)%p
    else: det=0
    return (rank,det,pivots,M) if return_piv else (rank,det)

print('rank/detmod B',rank_det_mod(B))
Dmat=[r['D'] for r in rows]
print('rank D',rank_det_mod(Dmat)[0])

# choose independent 7 rows for D via transpose pivot columns => row indices
# Gaussian on D rows directly track row selections greedily by rank increase
sel=[]; cur=[]
for i,row in enumerate(Dmat):
    rr=rank_det_mod(cur+[row])[0] if cur else (1 if any(row) else 0)
    if rr>len(cur): sel.append(i); cur.append(row)
    if len(sel)==7: break
print('D independent rows',sel)

# exact gaussian solve square A x=b
def solve_frac(A,b):
    n=len(A); M=[list(A[i])+[b[i]] for i in range(n)]
    for c in range(n):
        piv=next(r for r in range(c,n) if M[r][c])
        if piv!=c: M[c],M[piv]=M[piv],M[c]
        pv=M[c][c]
        M[c]=[x/pv for x in M[c]]
        for r in range(n):
            if r==c: continue
            f=M[r][c]
            if f:
                M[r]=[M[r][j]-f*M[c][j] for j in range(n+1)]
    return [M[i][-1] for i in range(n)]
A=[Dmat[i] for i in sel]; b=[res[i] for i in sel]
alpha=solve_frac(A,b)
print('alpha:')
for i,a in enumerate(alpha,1): print(i,a)

errs=[]
for i,(d,r) in enumerate(zip(Dmat,res)):
    pred=sum((a*x for a,x in zip(alpha,d)),F(0)); e=r-pred; errs.append(e)
    print('verify',i,e)
assert all(e==0 for e in errs)
withheld_pred=sum((a*x for a,x in zip(alpha,withheld['D'])),F(0))
withheld_err=withheld['residual']-withheld_pred
print('withheld b=',withheld['b'],'u=',withheld['u'],'error=',withheld_err)
assert withheld_err==0

# full coordinates solve on B: exact using all 11 rows (this also proves Q coords of residual are zero)
coordsR=solve_frac(B,res)
print('coords residual full:')
for i,x in enumerate(coordsR): print(i,x)
assert coordsR[:4]==[F(0)]*4
assert coordsR[4:]==alpha

cand=[F(106781,55738368000),F(49431,55738368000),F(2187,55738368000),F(-867,55738368000)]
Fvals=[r['F'] for r in rows]
coordsF=solve_frac(B,Fvals)
print('coords F full:')
for i,x in enumerate(coordsF): print(i,x)
assert coordsF[:4]==cand
assert coordsF[4:]==alpha

# exact determinant by row denominator clearing + Bareiss
from math import gcd
def lcm(a,b): return abs(a//gcd(a,b)*b)
row_scales=[]; IM=[]
for row in B:
    L=1
    for x in row: L=lcm(L,x.denominator)
    row_scales.append(L)
    IM.append([x.numerator*(L//x.denominator) for x in row])

def bareiss_det(A):
    A=[r[:] for r in A]; n=len(A); sign=1; prev=1
    for k in range(n-1):
        if A[k][k]==0:
            piv=next((r for r in range(k+1,n) if A[r][k]!=0),None)
            if piv is None:return 0
            A[k],A[piv]=A[piv],A[k]; sign*=-1
        pivot=A[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                A[i][j]=(A[i][j]*pivot-A[i][k]*A[k][j])//prev
        for i in range(k+1,n): A[i][k]=0
        prev=pivot
    return sign*A[-1][-1]
idet=bareiss_det(IM)
prodL=math.prod(row_scales)
detF=F(idet,prodL)
print('exact determinant numerator digits',len(str(abs(detF.numerator))))
print('exact determinant denominator digits',len(str(detF.denominator)))
print('exact determinant',detF)
print('det mod p from exact det',qmod(detF))
assert detF!=0

# save certificate txt concise
out=BASE / 'tau10_PROOF_B_exact_certificate.txt'
with out.open('w') as f:
    f.write('TAU^10 PROOF B — EXACT 5->4 CERTIFICATE\n')
    f.write('==========================================\n\n')
    f.write('Field: Q (Python Fraction); no floating point.\n')
    f.write('Vacuum family: Taub/Bianchi-II with fixed Kasner u=2, t=1, z=0; 11 rational b values.\n')
    f.write('All 11 Ricci tensors vanish exactly.\n\n')
    f.write('Basis columns: Q1=I2 I3, Q2=P2 P3, Q3=I2 (nabla C)^2, Q4=P2(nabla C.nabla *C), D1..D7 explicit divergences.\n')
    f.write(f'rank(B)=11; det(B) mod {P} = {rank_det_mod(B)[1]}; therefore det_Q(B) != 0.\n')
    f.write(f'Exact det(B) = {detF}\n\n')
    f.write('Residual R=F10-[106781 Q1+49431 Q2+2187 Q3-867 Q4]/55738368000.\n')
    f.write('Exact divergence coefficients alpha_i:\n')
    for i,a in enumerate(alpha,1): f.write(f'  alpha{i} = {a}\n')
    f.write('\nFull exact coordinates of R in [Q1,Q2,Q3,Q4,D1..D7]:\n  '+', '.join(map(str,coordsR))+'\n')
    f.write('The first four coordinates are exactly zero.\n')
    f.write('R-sum_i alpha_i D_i evaluates to exactly zero on all 11 probes.\n')
    f.write('Since dim S_even(10)=11 and B has nonzero exact determinant, these 11 evaluation functionals are injective on S_even(10); hence the identity is universal in the stated d=4 Ricci-flat parity-even on-shell/IBP class.\n\n')
    f.write('Full exact coordinates of F10 in [Q1,Q2,Q3,Q4,D1..D7]:\n  '+', '.join(map(str,coordsF))+'\n')
    f.write('Thus the four quotient coefficients are recovered exactly.\n\n')
    f.write(f'WITHHELD exact Taub probe: b={withheld["b"]}, u={withheld["u"]}; Ricci=0 exactly; residual-minus-divergences = {withheld_err}.\n\n')
    f.write('FINAL: 5->4 certificate PASS.\n')
print('wrote',out)

"""
Exact hypercubic-lattice boundary/interface counting for the Appendix M
local-lattice counterfamily (Section M.3).

For a regular bounded-degree nearest-neighbour block of linear size L in
s spatial dimensions:
    N(L)        = L**s                    (total sites, exact)
    interior(L) = max(L-2, 0)**s           (sites with no neighbour outside)
    boundary(L) = N(L) - interior(L)       (exact interface count)

Claim under test (M.3): boundary(L) ~ N(L)**((s-1)/s) as L -> infinity,
for EVERY s independently -- i.e. locality alone does not select any one
exponent; the exponent is set by the architecture (here: the dimension s
of the lattice), not by locality/finite-propagation/stability per se.
"""
from fractions import Fraction as F

def N_exact(L, s):
    return L**s

def boundary_exact(L, s):
    interior = max(L - 2, 0)**s
    return L**s - interior

def target_beta(s):
    return F(s - 1, s)

if __name__ == "__main__":
    for s in range(1, 6):
        print(f"s={s}  target beta=(s-1)/s = {target_beta(s)} = {float(target_beta(s)):.6f}")

"""Single entry point: runs the full Appendix M certificate suite and
prints PASS/FAIL summary lines a reviewer can grep for."""
import subprocess, sys
from pathlib import Path
BASE = Path(__file__).resolve().parent

print("### 1. Target exponents (definitional) ###")
subprocess.run([sys.executable, str(BASE / "lattice_exact.py")], check=True)
print()
print("### 2. Local-lattice counterfamily: local-exponent convergence + withheld extrapolation ###")
subprocess.run([sys.executable, str(BASE / "verify_lattice_exponents.py")], check=True)
print()
print("### 3. Tree and bottleneck counterfamilies ###")
subprocess.run([sys.executable, str(BASE / "tree_and_bottleneck.py")], check=True)
print()
print("CERTIFICATE SUMMARY:")
print("  PASS: five independent regular-lattice families (s=1..5) realize five distinct exact")
print("        exponents (s-1)/s, with local-exponent estimates converging monotonically to the")
print("        exact target and withheld extrapolation (>=10x the calibration size) matching the")
print("        exact count to <1% relative error in every case tested.")
print("  PASS: tree architecture gives a boundary fraction converging to 1/2 (order unity, beta~1),")
print("        not 2/3, confirming architecture dependence.")
print("  PASS: bottleneck architecture gives an exactly constant (N-independent) cut of size 1 for")
print("        every N tested, i.e. beta=0 exactly, the opposite extreme.")
print("  CONCLUSION: locality + finite propagation + stable coarse response alone realize at least")
print("        {beta=0, 1/2, 2/3, 3/4, 4/5, ~1} across explicit, exactly-countable architectures.")
print("        No universal beta=2/3 (hence no unique s=3) is selected by these principles alone.")
